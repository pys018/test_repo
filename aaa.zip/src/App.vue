<template>
    <div>
        <router-link to="/page1/1">Go to page1</router-link><br />
        <router-link to="/page2">Go to page2</router-link><br />
        <router-link to="/page3">Go to page3</router-link><br /><br />
        <router-link to="/testpage">Go to testpage</router-link><br /><br />
        <!-- <router-link to="/echartTestpage">Go to echart Testpage</router-link><br /><br /> -->
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name: "App",
    data: () => ({
        //
    }),
};
</script>
