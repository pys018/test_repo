<template>
    <div ref="chart" style="width:100%;height:100%">aaaaaaaa</div>
</template>

<script>
import echartsInstance from '@/mixin/echartsInstance'

export default {
  name: 'FICCChart',
  mixins: [echartsInstance],
  props: {
    data: Array  // Array of [date, x, y, size, 'rgb(n,n,n)']
  },
  computed: {
    chartOption: function () {
      return {
        title: null,
        tooltip: {},
        xAxis: {
          axisLabel: {show:false},
          splitLine: {show:false},
        },
        yAxis: {
          axisLabel: {show:false},
          splitLine: {show:false},
        },
        grid: {left:5, right:5, top:5, bottom:5},
        dataset: {source:this.data},
        series: [
          {
            type: 'scatter',
            encode: {x:1, y:2, tooltip:[0, 0]},
            symbolSize: v => v[3],
            itemStyle: {
              color: p => p.data[4],
              opacity: .7,
            },
            animation: false,
          },
          // {
          //   type: 'effectScatter',
          //   encode: {x:1, y:2, tooltip:[0, 0]},
          //   rippleEffect: {
          //     scale: 15,
          //     color: '#c6282877',
          //     brushType: 'fill',
          //     period: 10,
          //   },
          //   itemStyle: {color:'#b71c1c'},
          //   data: [this.data[this.data.length-1]],
          // }
        ]
      }
    }
  },
  // mounted () {
  //   this.echartsInstance.on('click', ({data}) => { this.$emit('click', data[0]) })
  // }
}
</script>

<style lang="scss" scoped>
.main {
  width: 100%; height: 100%;
  padding: 10px 20px;
  display: flex;
  flex-direction: column;
  
  .form {
    height: 60px;
    display: flex;
    
    .input {
      flex: 1;
      text-align: center;
      padding: 5px 10px;
      &:last-child { align-self:center }
    }
  }
  
  .content { flex:1 }
  .content-overview {
    width: 100%; height: 100%;
    display: flex;
    .chart {
      width: 70%; height: 100%;
      position: relative;
      .fab {
        position: absolute;
        bottom: 30px;
        right: 30px;
      }
    }
  }
  .content-detailed {
    width: 100%; height: 100%;
    display: flex;
    .chart {
      flex:1;
      display: flex;
      flex-direction: column;
      padding: 20px 10px;
      position: relative;
      .upper { flex:1 }
      .lower { flex:1; padding-top:10px }
    }
    .table {
      flex:1;
      padding: 20px 10px;
    }
  }
}
</style>

