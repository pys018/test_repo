<template>
    <div>
        <div>
            Component1 {{myMessage}}
        </div>
        <div>
            <button @click="$emit('child-event', 'childchild')">click me</button>
        </div>
    </div>
</template>

<script>
export default {
    name: 'component1',
    props: {
        myMessage:String
    },
    data() {
        return {
            
        };
    },
    mounted() {
        
    },
    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>