import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import router from './routes/index.js'
import store from './store/index.js';

import axios from 'axios'
import VueAxios from 'vue-axios'

import VueMask from 'v-mask'

// import echartsInstance from './mixin/echartsInstance.js'









Vue.use(VueAxios, axios)
Vue.use(VueMask)
    //Vue.use(echartsInstance)




Vue.config.productionTip = false

// console.log(process.env.VUE_APP_URL)
new Vue({
    vuetify,
    router,
    store,
    render: h => h(App)
}).$mount('#app')