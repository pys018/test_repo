// import echarts from 'echarts'
import * as echarts from 'echarts'

export default {
    data: () => ({
        chartInstance: null,
        isChartInitialized: false
    }),
    computed: {
        chartOption: function() {
            return {}
        }
    },
    watch: {
        chartOption: function() { this.isChartInitialized && this.plot() }
    },
    mounted() {
        this.plot()
        this.isChartInitialized = true
    },
    methods: {
        plot: function() {
            if (this.chartInstance === null) { this.chartInstance = echarts.init(this.$refs.chart) }
            this.chartInstance.setOption(this.chartOption, true)
        }
    }
}