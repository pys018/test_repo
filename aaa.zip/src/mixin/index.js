export const myMixin = {
    created: function () {
        
    },
    
}