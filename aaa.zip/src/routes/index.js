import Vue from 'vue'
import VueRouter from 'vue-router'
import page1 from '../views/page1.vue'
import page2 from '../views/page2.vue'
import page3 from '../views/page3.vue'
import testpage from '../views/testpage.vue'
// import echartTestpage from '../views/echartTestpage.vue'

Vue.use(VueRouter)

const router = new VueRouter({
    mode: 'history',
    routes: [{
            path: '/page1/:id',
            component: page1
        },
        {
            path: '/page2',
            component: page2
        },
        {
            path: '/page3',
            component: page3
        },
        {
            path: '/testpage',
            component: testpage
        },
        // {
        //     path: '/echartTestpage',
        //     component: echartTestpage
        // },
    ]
})

export default router;