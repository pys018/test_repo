<template>
    <v-app>
        Page1
        {{$route.params.id}}<br><br><br>

        <component1 :myMessage="msg" @child-event="test"/>

        <div>
            <input v-model="msg" placeholder="여기를 수정해보세요">
            <p>메시지: {{ msg }}</p>
        </div>
        <br><br><br>

        <!-- <form id="dashfrm" @submit="checkForm" action="/something" method="post" novalidate="true"> -->
            <div>
                <v-simple-table >
                    <tbody>
                        <tr>
                            <td width="99%" class="text-center">
                                FICC
                            </td>
                            <td width="1%" class="text-center">
                                ???
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <v-simple-table dense border="1">
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td>DATE(로컬)</td>
                                            <td>
                                                <!-- <v-menu
                                                    ref="menu1"
                                                    v-model="menu1"
                                                    :close-on-content-click="false"
                                                    transition="scale-transition"
                                                    offset-y
                                                    max-width="290px"
                                                    min-width="auto"
                                                >
                                                    <template v-slot:activator="{ on, attrs }">
                                                        <v-text-field
                                                            v-model="dateFormatted"
                                                            label=""
                                                            hint="YY-MM-DD"
                                                            persistent-hint
                                                            v-bind="attrs"
                                                            @blur="date = parseDate(dateFormatted)"
                                                            v-on="on"
                                                        ></v-text-field>
                                                    </template>
                                                    <v-date-picker
                                                        v-model="date"
                                                        no-title
                                                        @input="menu1 = false"
                                                    ></v-date-picker>
                                                </v-menu> -->

                                                <v-text-field
                                                    v-mask="'##-##-##'"
                                                    v-model="srchDate"
                                                    label=""
                                                    persistent-hint
                                                    placeholder="YY-MM-DD"
                                                ></v-text-field>
                                            </td>
                                            <td></td>
                                            <td>TIME(로컬)</td>
                                            <td>
                                                <v-text-field
                                                    v-mask="'##:##'"
                                                    v-model="srchTime"
                                                    label=""
                                                    persistent-hint
                                                    placeholder="HH:MM"
                                                ></v-text-field>
                                            </td>
                                            <td></td>
                                            <td>ASSET</td>
                                            <td>
                                                <v-autocomplete
                                                    v-model="assetSelected"
                                                    :items="assetOptions"
                                                    label=""
                                                    chips
                                                    color="blue"
                                                >
                                                </v-autocomplete>
                                            </td>
                                            <td></td>
                                            <td>OFFSET</td>
                                            <td>
                                                <v-select
                                                    v-model="offsetSelected"
                                                    :items="offsetOptions"
                                                    label=""
                                                ></v-select>
                                            </td>
                                            <td></td>
                                            <td>
                                                <v-btn block v-on:click="searchRun">
                                                    실행
                                                </v-btn>
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <v-checkbox v-model="realTimeChartChk">
                                                    <template v-slot:label>
                                                        <div>
                                                            RealTime Chart
                                                        </div>
                                                    </template>
                                                </v-checkbox>
                                            </td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <v-select
                                                    v-model="refreshSelected"
                                                    :items="refreshOptions"
                                                    label=""
                                                ></v-select>
                                            </td>
                                            <td></td>
                                            <td>
                                                <v-select
                                                    v-model="xaxisUnitSelected"
                                                    :items="xaxisUnitOptions"
                                                    label=""
                                                ></v-select>
                                            </td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </v-simple-table>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <v-simple-table dense border="1">
                                    <tbody>
                                        <tr>
                                            <td width="74%">
                                                <!-- <div class="chart">
                                                    <FICCChart
                                                        :data="chartData"
                                                    />
                                                </div> -->

                                                <chart
                                                :options="bar"
                                                :init-options="initOptions"
                                                ref="bar"
                                                theme="ovilia-green"
                                                autoresize
                                                />
                                            </td>
                                            <td width="1%"></td>
                                            <td width="25%">
                                                <v-text-field v-model="dateScoreSearch" single-line></v-text-field>
                                                <v-data-table
                                                    :headers="dateScoreHeaders"
                                                    :items="dateScoreDatas"
                                                    class="elevation-1"
                                                    :items-per-page="100"
                                                    hide-default-footer
                                                    :search="dateScoreSearch"
                                                ></v-data-table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </v-simple-table>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                ▣ CASE FICC Result
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <!-- <v-data-table
                                    :headers="caseResultHeaders"
                                    :items="caseResultDatas"
                                    class="elevation-1"
                                    hide-default-footer
                                    :items-class="itemRowBackground"
                                ></v-data-table> -->

                                <v-data-table
                                    :headers="caseResultHeaders"
                                    :items="caseResultDatas"
                                    class="elevation-1"
                                    hide-default-footer
                                    @click:row="clickRow"
                                    @dblclick:row="dblclickRow"
                                >
                                    <!-- <template v-slot:item="{ item }">
                                        <tr>
                                            <td>{{ item.resultCategoryVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D1HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D2HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D3HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D4HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D5HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result0D6HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result1D0HVal }}</td>
                                            <td :style="itemRowBackground(item)">{{ item.result2D0HVal }}</td>
                                        </tr>
                                    </template> -->
                                    <template v-slot:item="{ item }">
                                        <!-- <tr v-if="item.resultCategoryVal=='CASE UP'"> -->
                                        <tr>
                                            <td >{{ item.resultCategoryVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D1HVal)">{{ item.result0D1HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D2HVal)">{{ item.result0D2HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D3HVal)">{{ item.result0D3HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D4HVal)">{{ item.result0D4HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D5HVal)">{{ item.result0D5HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result0D6HVal)">{{ item.result0D6HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result1D0HVal)">{{ item.result1D0HVal }}</td>
                                            <td :style="itemRowBackground(item.resultCategoryVal,item.result2D0HVal)">{{ item.result2D0HVal }}</td>
                                        </tr>
                                    </template>
                                </v-data-table>

                                <!-- <v-simple-table dense border="1">
                                    <tbody>
                                        <tr>
                                            <td>Category</td>
                                            <td>OD+1H</td>
                                            <td>OD+2H</td>
                                            <td>OD+3H</td>
                                            <td>OD+4H</td>
                                            <td>OD+5H</td>
                                            <td>OD+6H</td>
                                            <td>1D+0H</td>
                                            <td>2D+0H</td>
                                        </tr>
                                        <tr>
                                            <td>CASE UP</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>CASE DOWN</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </v-simple-table> -->
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                666
                            </td>
                        </tr>
                    </tbody>

                </v-simple-table>
            </div>
        <!-- </form> -->

    </v-app>
</template>

<script>
import component1 from '../components/component1.vue'
// import FICCChart from '../components/charts/FICCChart.vue'

import ECharts from '../components/ECharts.vue'
import getBar from '../components/bar'

/**
* Generate a time mask based on input value (23:59)
* @param {string} value
*/
// export function timeMask(value) {
//     const hours = [
//         /[0-2]/,
//         value.charAt(0) === '2' ? /[0-3]/ : /[0-9]/,
//     ];
//     const minutes = [/[0-5]/, /[0-9]/];
//     return value.length > 2
//         ? [...hours, ':', ...minutes]
//         : hours;
// }

/**
* Generate a time range mask based on input value (00:00-23:59)
* @param {string} value
*/
// export function timeRangeMask(value) {
//     const numbers = value.replace(/[^0-9]/g, '');
//     if (numbers.length > 4) {
//         return [...timeMask(numbers.substring(0, 4)), '-', ...timeMask(numbers.substring(4))];
//     }
//     return [...timeMask(numbers)];
// }

export default {
    name: 'page1',
    components: {
        component1,
        // FICCChart,
        chart: ECharts
    },

    data: vm => ({
        msg: 'ZZZZZ',

        assetSelected: 'KTB3YF',
        assetOptions: [
            { text: 'KTB3YF', value: 'KTB3YF' },
            { text: 'KTB10YF', value: 'KTB10YF' },
            { text: 'UST2YF', value: 'UST2YF' },
            { text: 'UST5YF', value: 'UST5YF' },
            { text: 'UST10YF', value: 'UST10YF' },
            { text: 'USDKRWF', value: 'USDKRWF' },
            { text: 'EURKRWF', value: 'EURKRWF' },
            { text: 'JPYKRWF', value: 'JPYKRWF' },
        ],

        offsetSelected: 'N',
        offsetOptions: [
            { text: 'Now Price', value: 'N' },
            { text: 'Close Price', value: 'C' },
        ],

        refreshSelected: '30',
        refreshOptions: [
            { text: 'Refresh 5min', value: '5' },
            { text: 'Refresh 10min', value: '10' },
            { text: 'Refresh 30min', value: '30' },
            { text: 'Refresh 60min', value: '60' },
        ],

        xaxisUnitSelected: '30',
        xaxisUnitOptions: [
            { text: '5min', value: '5' },
            { text: '10min', value: '10' },
            { text: '30min', value: '30' },
            { text: '60min', value: '60' },
            { text: '1day', value: '1D' },
        ],


        date: new Date().toISOString().substr(0, 10),
        dateFormatted: vm.formatDate(new Date().toISOString().substr(0, 10)),
        menu1: false,
        menu2: false,


        srchDate: '',

        srchTime: '',

        realTimeChartChk: false,

        dateScoreSearch: '',
        dateScoreHeaders: [
            {
                text: 'DATE',
                align: 'start',
                sortable: true,
                value: 'dateVal',
            },
            {
                text: 'Score',
                value: 'scoreVal',
            },
        ],
        dateScoreDatas: [
            {
                dateVal: '20201112',
                scoreVal: 100,
            },
            {
                dateVal: '20190711',
                scoreVal: 23.66,
            },
            {
                dateVal: '20160627',
                scoreVal: 23.49,
            },
            {
                dateVal: '20150703',
                scoreVal: 19.04,
            },
            {
                dateVal: '20190628',
                scoreVal: 16.38,
            },
            {
                dateVal: '20191015',
                scoreVal: 15.2,
            },
            {
                dateVal: '20170206',
                scoreVal: 13.13,
            },
            {
                dateVal: '20171103',
                scoreVal: 12.46,
            },
            {
                dateVal: '20190807',
                scoreVal: 10.48,
            },
            {
                dateVal: '20180626',
                scoreVal: 9.64,
            },
            {
                dateVal: '20200128',
                scoreVal: 8.78,
            },
            {
                dateVal: '20201007',
                scoreVal: 6.76,
            },
            {
                dateVal: '20170712',
                scoreVal: 5.25,
            },
            {
                dateVal: '20160913',
                scoreVal: 4.74,
            },
            {
                dateVal: '20151124',
                scoreVal: 3.95,
            },
            {
                dateVal: '20170824',
                scoreVal: 2.67,
            },
            {
                dateVal: '20191031',
                scoreVal: 0.8,
            },
            {
                dateVal: '20150224',
                scoreVal: 0.76,
            },
        ],

        caseResultHeaders: [
            {
                text: 'Category',
                align: 'start',
                sortable: false,
                value: 'resultCategoryVal',
            },
            {
                text: '0D+1H',
                sortable: false,
                value: 'result0D1HVal',
            },
            {
                text: '0D+2H',
                sortable: false,
                value: 'result0D2HVal',
            },
            {
                text: '0D+3H',
                sortable: false,
                value: 'result0D3HVal',
            },
            {
                text: '0D+4H',
                sortable: false,
                value: 'result0D4HVal',
            },
            {
                text: '0D+5H',
                sortable: false,
                value: 'result0D5HVal',
            },
            {
                text: '0D+6H',
                sortable: false,
                value: 'result0D6HVal',
            },
            {
                text: '1D+0H',
                sortable: false,
                value: 'result1D0HVal',
            },
            {
                text: '2D+0H',
                sortable: false,
                value: 'result2D0HVal',
            },
        ],
        caseResultDatas: [
            {
                resultCategoryVal: 'CASE UP',
                result0D1HVal: '-',
                result0D2HVal: '-',
                result0D3HVal: '-',
                result0D4HVal: '-',
                result0D5HVal: '-',
                result0D6HVal: '-',
                result1D0HVal: '49.95',
                result2D0HVal: '54.13',
            },
            {
                resultCategoryVal: 'CASE DOWN',
                result0D1HVal: '-',
                result0D2HVal: '-',
                result0D3HVal: '-',
                result0D4HVal: '-',
                result0D5HVal: '-',
                result0D6HVal: '-',
                result1D0HVal: '50.04',
                result2D0HVal: '45.86',
            },
        ],

        // 알림 팝업 오픈하기 위한 변수
        // result0D1HValUP: '',
        // result0D2HValUP: '',
        // result0D3HValUP: '',
        // result0D4HValUP: '',
        // result0D5HValUP: '',
        // result0D6HValUP: '',
        // result1D0HValUP: '',
        // result2D0HValUP: '',

        // result0D1HValDOWN: '',
        // result0D2HValDOWN: '',
        // result0D3HValDOWN: '',
        // result0D4HValDOWN: '',
        // result0D5HValDOWN: '',
        // result0D6HValDOWN: '',
        // result1D0HValDOWN: '',
        // result2D0HValDOWN: '',

        chartData: null,

        bar: getBar(),
        initOptions: null,
    }),

    computed: {
        computedDateFormatted () {
            return this.formatDate(this.date)
        },
    },

    watch: {
        date (val) {
            console.log(">>>>> watch >>> this.date ::: " + this.date);
            this.dateFormatted = this.formatDate(this.date)
        },
    },

    mounted() {
        //this.loadData()
        this.initData()

        // this.itemRowBackground()
    },

    methods: {
        test: function(param) {
            console.log('test' + param)
        },

        formatDate (date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${year}-${month}-${day}`
        },
        parseDate (date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${year}-${month}-${day}`
        },

        // loadData : async function () {
        //     try {
        //         const response = await backend.get(`/deep-learning/assetwise/${this.$route.params.assetClass}/recent`)
        //         this.analysis = response.data
        //     } catch (err) {
        //         console.error('API Error')
        //     }
        // },

        initData: function(param) {
            let offset = new Date().getTimezoneOffset() * 60000;
            let today = new Date(Date.now() - offset);
            console.log(">>>>> today 111 ::: " + today);
            today = today.toISOString();
            console.log(">>>>> today 222 ::: " + today);
            this.srchDate = today.substr(2, 8);

            this.srchTime = today.substr(11, 5);
        },

        searchRun: function() {
            let valChkDate = this.srchDate.replace(/-/g,'');
            console.log("methods >>> valChkDate ::: ", valChkDate);
            if(valChkDate == null || valChkDate == '' || valChkDate.length != 6) {
                alert("DATE를 확인해주세요.");
                return;
            }

            let valChkTime = this.srchTime.replace(':','');
            console.log("methods >>> valChkTime ::: ", valChkTime);
            if(valChkTime == null || valChkTime == '' || valChkTime.length != 4) {
                alert("TIME를 확인해주세요.");
                return;
            }
        },

        itemRowBackground: function(category, item) {
            console.log("methods >>> category ::: " + category + "   >>> item ::: " + item);
            // console.log("methods >>> itemRowBackground ::: ", JSON.stringify(item));
            // return item > 50 ? '.style-1' : '.style-2';

            // let tmpCategoryVal = item.resultCategoryVal;
            // console.log("methods >>> tmpCategoryVal ::: ", tmpCategoryVal);

            // this.result0D1HValUP = item.result0D1HVal;
            // this.result0D2HValUP = item.result0D2HVal;
            // this.result0D3HValUP = item.result0D3HVal;
            // this.result0D4HValUP = item.result0D4HVal;
            // this.result0D5HValUP = item.result0D5HVal;
            // this.result0D6HValUP = item.result0D6HVal;
            // this.result1D0HValUP = item.result1D0HVal;
            // this.result2D0HValUP = item.result2D0HVal;

            // this.result0D1HValDOWN = item.result0D1HVal;
            // this.result0D2HValDOWN = item.result0D2HVal;
            // this.result0D3HValDOWN = item.result0D3HVal;
            // this.result0D4HValDOWN = item.result0D4HVal;
            // this.result0D5HValDOWN = item.result0D5HVal;
            // this.result0D6HValDOWN = item.result0D6HVal;
            // this.result1D0HValDOWN = item.result1D0HVal;
            // this.result2D0HValDOWN = item.result2D0HVal;

            // if(this.result0D1HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result0D2HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result0D3HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result0D4HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result0D5HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result0D6HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result1D0HValUP >= 50) {
            //     return 'background-color:red';
            // } else if(this.result2D0HValUP >= 50) {
            //     return 'background-color:red';

            // } else if(this.result0D1HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result0D2HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result0D3HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result0D4HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result0D5HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result0D6HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result1D0HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else if(this.result2D0HValDOWN >= 50) {
            //     return 'background-color:blue';
            // } else {
            //     return '';
            // }


            // if(item.result0D1HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result0D2HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result0D3HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result0D4HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result0D5HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result0D6HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result1D0HVal >= 50) {
            //     return 'background-color:red';
            // } else if(item.result2D0HVal >= 50) {
            //     return 'background-color:red';

            // } else if(item.result0D1HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result0D2HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result0D3HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result0D4HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result0D5HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result0D6HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result1D0HVal >= 50) {
            //     return 'background-color:blue';
            // } else if(item.result2D0HVal >= 50) {
            //     return 'background-color:blue';
            // } else {
            //     return '';
            // }

            if(category == 'CASE UP') {
                if(item >= 50) {
                    return 'background-color:red';
                } else {
                    return '';
                }
            } else if(category == 'CASE DOWN') {
                if(item >= 50) {
                    return 'background-color:blue';
                } else {
                    return '';
                }
            } else {
                return '';
            }
        },

        dblclickRow() {
            console.log("rowDoubleClicked");
        },
        clickRow() {
            console.log("rowClicked");
        }
    },
};
</script>

<style scoped>
/* .inputPrice input[type='number'] {
    -moz-appearance:textfield;
}
.inputPrice input::-webkit-outer-spin-button,
.inputPrice input::-webkit-inner-spin-button {
    -webkit-appearance: none;
} */


table {
    width: 100%;
    border: 1px solid #444444;
    border-collapse: collapse;
}
th, td {
    border: 1px solid #444444;
    padding: 10px;
}


.style-1 {
    background-color: rgb(215, 215, 44)
}
.style-2 {
    background-color: rgb(114, 114, 67)
}



  .v-data-table header {
    font-size: 14px;
  }
 .v-data-table th {
   font-size: 12px;
 }
 .v-data-table td {
   font-size: 12px;
 }
</style>
