<template>
    <div>
        Page2<br>
        <button @click="move()">go to page3</button>
    </div>
</template>

<script>
export default {
    name: 'page2',
    data() {
        return {

        };
    },
    mounted() {

    },
    methods: {
        move : function() {
            this.$router.push({path:'page3'})
        }
    },
};
</script>

<style>

</style>
