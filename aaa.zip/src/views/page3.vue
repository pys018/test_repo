<template>
    <div>
        Page3
    </div>
</template>

<script>
export default {
    name: 'page3',
    data() {
        return {

        };
    },
    mounted() {

    },
    methods: {

    },
};
</script>

<style>

</style>