<template>
    <div id="app">
        <v-app id="inspire">
            <v-card>
                <v-card-text>
                    <v-layout wrap>
                        <v-flex xs3 md3>
                            <v-autocomplete
                                v-model="product"
                                :items="products"
                                label=""
                                chips
                                color="blue"
                            >
                            </v-autocomplete>
                        </v-flex>
                    </v-layout>
                </v-card-text>
            </v-card>
        </v-app>
    </div>
</template>

<script>
export default {
    name: 'testpage',
    data () {
        return {
            model: null,
            product: null,
            category: null,
            purpose: null,
            products: [
                'Samson', 'Wichita', 'Combustion', 'Triton',
                'Helios', 'Wimbeldon', 'Brixton', 'Iguana',
                'Xeon', 'Falsy', 'Armagedon', 'Zepellin'],
        }
    },
    computed: {
        categories() {
            return Object.keys(this.categoriesPurposes)
        },
        purposes() {
            if (!this.category) {
                return null
            } else {
                return this.categoriesPurposes[this.category]
            }
        }
    }
};
</script>

<style>

</style>