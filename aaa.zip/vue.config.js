module.exports = {
    transpileDependencies: [
        'vuetify',
        'vue-echarts',
        'resize-detector'
    ]
}