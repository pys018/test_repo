﻿<template>
	<div>
		<highcharts class="hc" :options="chartOptions" ref="chart"></highcharts>

		<v-btn block v-on:click="gridOnOff">
			Grid On/Off
		</v-btn>
		<v-btn block v-on:click="redrawChart">
			Redraw Chart
		</v-btn>
	</div>
</template>

<script>
export default {
	//data() {
		//return {
			//chartOptions: {

			//}
		//}
	//};
	data: () => ({
		seriesData: [
			{
				name:'20201211',
				lineWidth: 1,
				data: [-0.1760, 0.1356, 0.3715, 1.11292, 0.21064, 0.1760, 1.1356, 0.1760, 0.11292, 3.4299, 3.1292, 3.21064, 0.0760, 0.01760, 0.1356, 0.3715, 0.11292, 0.21064, 0.1760, 0.01356, 0.0760, -2.01760, 0.1356, 0.0760, 2.21064, 0.01760, 2.21064, 0.01760, 0.01760, -1.01356, 2.1760, 0.11292, 3.4299, 2.1760, 2.1356, 0.1129, 0.1356, 1.4299, 2.1292, 0.01760, -1.01356, 2.11292, 1.21064, 3.1760, -1.01356, -0.1232, 2.61064, 1.0760, -3.01760, 2.1356, 1.3785, 2.1729, 1.1356, -2.3715, 1.15692, 2.21064, 1.6860, -3.89356, -1.01356],
				color: '#8B00FF'	// 보라색
			},
			{
				name:'20191211',
				lineWidth: 2,
				data: ['', '', '', -5.7485, -2.1760, 0.11292, 3.4299, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356],
				color: '#FF3399'	// 분홍색
			},
			{
				name:'20181211',
				lineWidth: 3,
				data: [-3.4299, 0.3715, 0.1292, 3.21064, 0.0760, 2.21064, 2.1760, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, -0.4299, 0.3715, 0.1292, 3.21064, 0.0760, 2.21064, 2.1760, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, 0.1356, 3.3715, 0.1129, -1.01356, 2.11292, 0.1129, 0.1356, 2.1760, 2.1356, 0.01760, 2.21064, 0.1356, -3.3715, 1.3785, 2.1729, 0.01760, 2.21064, -3.3715, 0.11292, 0.0760, -2.01760, -1.01356, 0.1129],
				color: '#FFA500'	// 주황색
			},
			{
				name:'20201114',
				lineWidth: 4,
				data: [0.4299, 0.715, 0.21064, 0.11292, 0.01440, 0.01760, -1.01356, 0.01440, 1.01760, -1.01356, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, -0.4299, 0.3715, -1.01356, 0.01440, 1.01760, -1.01356, 2.1356, 0.01760, 2.21064 ,0.01760],
				color: '#FF0000'	// 빨간색
			},
		],

		chartOptions: {
			chart: {
				//backgroundColor: '#323232',
				backgroundColor: 'White',
				ignoreHiddenSeries: true,	// serise 영역감추기
				spacingRight:122,			// right 여백
				type: 'line',				// 라인타입 종류  'spline', 'line'
				zoomType: 'x',				// x.y축 드래그줌인
			},
			title: {
				text: '',
			},
			legend: {
				floating: false,
				layout: 'vertical',
				borderWidth: 1,
				borderColor: '#444444',	// #444444, White
				borderCornerRadius: 5,
				shadow: true,
				//backgroundColor: 'rgba(32, 32, 32, .75)',
				backgroundColor: '#FFFFFF',
				align: 'right',
				//x: 1370,
				verticalAlign: 'top',
				//y: 35,
				itemStyle: {
					color: '#CCCCCC',
					listStyle: 'none',
					listStyleImage: 'none'
				},
				itemHiddenStyle: {
					color: '#444444'
				},
				itemHoverStyle: {
					color: 'white'
				}
			},

			/*
			tooltip: {
				//xDateFormat: '%Y-%m-%d',	// 적용시 datatime 가져오지못함
				crosshairs: true,
				shared: true,
				valueDecimals: 2,
			},
			*/
			tooltip: {
				crosshairs: true,
				shared: true,

				/*
				formatter: function () {
					return this.points.reduce(function (s, point) {
						//console.log(">>>>> tooltip ::: s ::: ", s);
						return s + '<br/>' + point.series.name + ': ' + point.y + 'm';
					}, '<b>' + this.x + '</b>');
				},
				*/

				// formatter: function (tooltip) {
				// 	//console.log(">>>>> tooltip ::: ", tooltip);
				// 	if(this.point.isNull) {
				// 		return 'Null';
				// 	}
				// 	// If not null, use the default formatter
				// 	return tooltip.defaultFormatter.call(this, tooltip);
				// }


				// formatter: function() {
				// 	var formatStr = "";

				// 	for(var i = 0; i < this.points.length; i++) {
				// 		var point = this.points[i];
				// 		console.log('>>>>> point ::: ', point);

				// 		// Highcharts wont format the numbers (point.y) once we've taken control of the tooltip
				// 		formatStr += '<span style="color:' + point.color + '">〓</span>' + point.series.name + ' lost: <b>£' + point.y + '</b><span> per person</span><br/>';
				// 	}

				// 	return formatStr;
				// },

				formatter: function() {
					var tmpXval = this.x;
					console.log('>>>>> tmpXval ::: ', tmpXval);

					// for(var i = 0; i < this.xAxisDateTimeDatas.length; i++) {
					// 	var skeyVal = this.xAxisDateTimeDatas[i].keyVal;
					// 	console.log(">>>>> skeyVal ::: ", skeyVal);
					// }
					// this.xAxisDateTimeDatas.forEach((element) => {
					// 	var skeyVal = element.keyVal;
					// 	console.log(">>>>> skeyVal ::: ", skeyVal);
					// });
					console.log(">>>>> this.xAxisDateTimeDatas ::: ", this.xAxisDateTimeDatas);




					var s = '<b>'+ this.x +'</b>';

					for(var j = 0; j < this.points.length; j++) {
						var point = this.points[j];
						console.log('>>>>> point ::: ', point);

						// 아래와 같이 point 객체의 정보를 사용 가능
						s += '<br/>' + point.series.name + ': ' + point.y;
					}

					return s;
				},
			},

			plotOptions: {
				series: {
					marker: {
						enabled: false
					},
				}
			},
			yAxis: {
				lineWidth: 1,
				minorGridLineWidth: 0,
				minorTickInterval: 'auto',
				minorTickPosition: 'inside',
				minorTickWidth: 1,
			},
			xAxis: {
				//minRange: 5,		// 최대leng값 적용하기 힘들것같음..
				lineWidth: 1,
				//lineColor: '#CCCCCC',

				minTickInterval: 5,

				gridLineColor: '#ccc',
				gridLineWidth: 1,

				minorGridLineColor: '#E0E0E0',
				minorGridLineDashStyle: 'Solid',
				minorGridLineWidth: 1,
				minorTickWidth: 1,
				minorTickInterval: 'auto',
				minorTickPosition: 'inside',


				tickPixelInterval: 1,
				tickLength: 3,
				tickWidth: 1,
				tickColor: '#FF0000',
				tickPosition: 'outside', // 'inside' or 'outside'


				crosshair: {
					width: 2,
					color: 'gray'
				},
				type: 'category',
				plotLines: [
					{
						color: "black",
						width: 1,
						label: {
							style:{
								color:"#6F6F6F"
							},
							color: "#5C5C5C",
							text: "20201112",				// 표시하는 날짜
							rotation: 90,
							align: "right",
							y: 305
						},
						value: 18,							// 표시하는 위치
					},
					{
						color: "black",
						width: 1,
						label: {
							style:{
								color:"#6F6F6F"
							},
							color: "#5C5C5C",
							text: "20201113",				// 표시하는 날짜
							rotation: 90,
							align: "right",
							y: 305
						},
						value: 25,							// 표시하는 위치
					},
					{
						// 현재시간 red line
						color: '#FF0000',
						width: 2,
						label: {
							style:{
								color:"#6F6F6F"
							},
							color: "#5C5C5C",
							text: "+0 days, 20201114(1525)",// 표시하는 날짜/시간	//plot band 적용안됨
							//rotation: 90,
							align: "right",
							y: 305
						},
						value: 30,							// 표시하는 위치
					},
					{
						color: "black",
						width: 1,
						label: {
							style:{
								color:"#6F6F6F"
							},
							color: "#5C5C5C",
							text: "+1 days, 20201115",		// 표시하는 날짜
							rotation: 90,
							align: "right",
							y: 305
						},
						value: 31,							// 표시하는 위치
					},
					{
						color: "black",
						width: 1,
						label: {
							style:{
								color:"#6F6F6F"
							},
							color: "#5C5C5C",
							text: "+2days, 20201116",		// 표시하는 날짜
							rotation: 90,
							align: "right",
							y: 305
						},
						value: 40,							// 표시하는 위치
					},
					{
						color: "#494949",	//그래프 시작선
						width: 1,  
						value: -0.5
					},
					{
						color: "#494949",	//그래프 끝선 
						width: 1,  
						value: 58
					},
				],

				// uniqueNames: true,	// tooltip 상세 부제목 활성화

				// x축 title
				categories: ["-30 20210209 1530", -29, -28, -27, -26, -25, -24, -23, -22, -21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],

				//pointStart: Date.UTC(2020, 0, 1),
				//pointInterval: 365,

				title: {
					x: 50,
					textAlign: 'left',
					width: 10,
				},

				/*
				axisLabel: {
					formatter: function (value) {
						return this.formatValue(value, 0);
					}
				},
				*/
				// labels: {
				// 	//format: '{value} $',
				// 	format: formatValue('{value}', 0)
				// },
			},
			//일반 x축 데이터 (x-y 둘다 적용 시 [ , ]) [[X,Y],[X,Y]]
			series: [
				{
					name:'20201211',
					lineWidth: 1,
					data: [-0.1760, 0.1356, 0.3715, 1.11292, 0.21064, 0.1760, 1.1356, 0.1760, 0.11292, 3.4299, 3.1292, 3.21064, 0.0760, 0.01760, 0.1356, 0.3715, 0.11292, 0.21064, 0.1760, 0.01356, 0.0760, -2.01760, 0.1356, 0.0760, 2.21064, 0.01760, 2.21064, 0.01760, 0.01760, -1.01356, 2.1760, 0.11292, 3.4299, 2.1760, 2.1356, 0.1129, 0.1356, 1.4299, 2.1292, 0.01760, -1.01356, 2.11292, 1.21064, 3.1760, -1.01356, -0.1232, 2.61064, 1.0760, -3.01760, 2.1356, 1.3785, 2.1729, 1.1356, -2.3715, 1.15692, 2.21064, 1.6860, -3.89356, -1.01356],
					color: '#8B00FF'	// 보라색
				},
				{
					name:'20191211',
					lineWidth: 2,
					data: ['', '', '', -5.7485, -2.1760, 0.11292, 3.4299, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356, -1.1292, 3.21064, 0.0760, -2.01760, 0.1356, 3.3715, 0.1129, 0.1356, -3.3715, 0.11292, 4.21064, 3.1760, -1.01356],
					color: '#FF3399'	// 분홍색
				},
				{
					name:'20181211',
					lineWidth: 3,
					data: [-3.4299, 0.3715, 0.1292, 3.21064, 0.0760, 2.21064, 2.1760, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, -0.4299, 0.3715, 0.1292, 3.21064, 0.0760, 2.21064, 2.1760, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, 0.1356, 3.3715, 0.1129, -1.01356, 2.11292, 0.1129, 0.1356, 2.1760, 2.1356, 0.01760, 2.21064, 0.1356, -3.3715, 1.3785, 2.1729, 0.01760, 2.21064, -3.3715, 0.11292, 0.0760, -2.01760, -1.01356, 0.1129],
					color: '#FFA500'	// 주황색
				},
				{
					name:'20201114',
					lineWidth: 4,
					data: [0.4299, 0.715, 0.21064, 0.11292, 0.01440, 0.01760, -1.01356, 0.01440, 1.01760, -1.01356, 2.1356, 0.01760, 2.21064, 0.01760, -1.01356, 0.1760, 3.11292, 3.4299, 3.1292, 0.01356, -2.01356, -0.4299, 0.3715, -1.01356, 0.01440, 1.01760, -1.01356, 2.1356, 0.01760, 2.21064 ,0.01760],
					color: '#FF0000'	// 빨간색
				},

				//this.seriesData
			],
		},	// chartOptions END


		// 차트 툴팁에서 X축 값과 대응되는 날짜/시간을 표시하기 위한 데이타
        xAxisDateTimeDatas: [
            {
                keyVal: -10,
                dateVal: '20201112 1200',
            },
            {
                keyVal: -9,
                dateVal: '20201112 1230',
            },
            {
                keyVal: -8,
                dateVal: '20201112 1300',
            },
            {
                keyVal: -7,
                dateVal: '20201112 1330',
            },
            {
                keyVal: -6,
                dateVal: '20201112 1400',
            },
            {
                keyVal: -5,
                dateVal: '20201112 1430',
            },
            {
                keyVal: -4,
                dateVal: '20201112 ZZZZ',
            },
            {
                keyVal: -3,
                dateVal: '20201112 XXXX',
            },
            {
                keyVal: -2,
                dateVal: '20201112 CCCC',
            },
            {
                keyVal: -1,
                dateVal: '20201112 VVVV',
            },
            {
                keyVal: 0,
                dateVal: '20201112 1530',
            },
            {
                keyVal: 1,
                dateVal: '20201112',
            },
            {
                keyVal: 2,
                dateVal: '20201112',
            },
            {
                keyVal: 3,
                dateVal: '20201112',
            },
            {
                keyVal: 4,
                dateVal: '20201112',
            },
            {
                keyVal: 5,
                dateVal: '20201112',
            },
            {
                keyVal: 6,
                dateVal: '20201112',
            },
            {
                keyVal: 7,
                dateVal: '20201112',
            },
            {
                keyVal: 8,
                dateVal: '20201112',
            },
            {
                keyVal: 9,
                dateVal: '20201112',
            },
            {
                keyVal: 10,
                dateVal: '20201112',
            },
		],

	}),		// data () END

    methods: {
        gridOnOff: function() {
			console.log('>>>>> gridOnOff <<<<<')

			// chart.series[0].update({
			// 	color: color ? null : Highcharts.getOptions().colors[1]
			// });
			// color = !color;

			//this.chartOptions.title.text = 'XXXXX';
			this.chartOptions.yAxis.minorGridLineWidth = 0;

			// Date On/Off 제어하기
			this.chartOptions.xAxis.plotLines[0].label.text = '';

		},

		redrawChart() {
			// HighchartsVue.redraw();

			var chart = this.$refs.chart;
			if(!chart) {
				console.log('>>>>> redrawChart :::  chart is null')
				return;
			} else {
				console.log('>>>>> redrawChart :::  chart is not null', chart)
				//chart.xAxis[0].setCategories(year);
				//chart.chartOptions.xAxis.lineWidth = 10;
				//chart.xAxis.crosshair.width = 20;
				return;
			}
		},

		formatValue(value, format) {
			console.log(">>>>> formatValue >>> value ::: " + value);

			switch(format)
			{
				case 0:
					//value = "x-" + value;
					var tmpVal = value.split(' ');
					value = tmpVal[0];
					break;
				case 1:
					//value = "y1-" + value;
					if(value == null) {
						return;
					}
					break;
				case 2:
					//value = "y2-" + value;
					break;
			}
			return value;
		},

	},

	computed: {
		computedCount() {
			console.log('computed');
			return this.countComputed;
		},

		// 차트 툴팁에서 X축 값과 대응되는 날짜/시간을 표시하기 위한 데이타
		/*
        computedxAxisDateTime () {
			var xAxisDateTimeDatas = new Map();

			xAxisDateTimeDatas.set("-5", "20201112 1200");
			xAxisDateTimeDatas.set("-4", "20201112 1230");
			xAxisDateTimeDatas.set("-3", "20201112 1300");
			xAxisDateTimeDatas.set("-2", "20201112 1330");
			xAxisDateTimeDatas.set("-1", "20201112 1400");
			xAxisDateTimeDatas.set("0", "20201112 1430");
			xAxisDateTimeDatas.set("1", "20201112 1500");
			xAxisDateTimeDatas.set("2", "20201112 1530");
			xAxisDateTimeDatas.set("3", "20201113 0900");
			xAxisDateTimeDatas.set("4", "20201113 0930");
			xAxisDateTimeDatas.set("5", "20201113 1000");

            return xAxisDateTimeDatas;
		},
		*/

	},
};
</script>
