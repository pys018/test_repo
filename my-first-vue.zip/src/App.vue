<template>
  <div>
    <h1>{{ title }}</h1>
    <h3>{{ dragon }}</h3>
    <button @click="dragon++">추가</button>
    <HomeComponent></HomeComponent>
    <Dragon></Dragon>
    <Chart></Chart>
  </div>
</template>
<script>
//import로 컴포넌드 모듈을 가져온다.
import HomeComponent from "./Home.vue"

  export default {
    components: {
      HomeComponent
    },
    data () {
      return {
        title: "안녕하세요",
        dragon: 1
      }
    },
    methods: {
      vov: function () {
        this.dragon++;
      }
    },
  }
</script>
