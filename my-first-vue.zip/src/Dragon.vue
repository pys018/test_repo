<template>
  <div>
    <h1>{{ dragon }}이 나타났다.</h1>
  </div>
</template>
<script>
export default {
  data () {
    return {
      dragon: "블루드래곤"
    }
  },
}
</script>
<style>
  
</style>
