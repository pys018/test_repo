<template>
  <div>
    <h1>{{ homeTitle }}</h1>
    <Dragon></Dragon>
  </div>
</template>
<script>
import Dragon from './Dragon.vue'
export default {
  components: { Dragon },
  data () {
    return {
      homeTitle: "홈 입니다."
    }
  },
}
</script>
<style>
  
</style>