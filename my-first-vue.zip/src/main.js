import Vue from 'vue'
import './plugins/vuetify'
import App from './App.vue'
// import router from './router'
// import store from './store'
// import vuetify from './plugins/vuetify';
import dragonComponent from './Dragon.vue'
import chartComponent from './Chart.vue'

Vue.component('Dragon', dragonComponent)
Vue.component('Chart', chartComponent)

Vue.config.productionTip = false

new Vue({
    // vuetify,
    render: h => h(App)
}).$mount('#app')