
-- ���� ���̺�
CREATE TABLE `TMDAMD300` (
  `data_cretn_ymd` varchar(8) NULL,
  `data_cretn_hhmm` varchar(4) NULL,
  `clsngprc` double(24,8) DEFAULT NULL,
  `fndt_asst_items_cd` varchar(30) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8
;

-- ���� ���̺�
CREATE TABLE `TMDAMD301` (
  `data_cretn_ymd` varchar(8) NULL,
  `data_cretn_hhmm` varchar(4) NULL,
  `clsngprc` double(24,8) DEFAULT NULL,
  `fndt_asst_items_cd` varchar(30) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8
;

-- DATE / SCORE ���̺�
#CREATE TABLE `TMDAMD302` (
#  `base_ymd` varchar(8) NOT NULL,
#  `data_cretn_ymd` varchar(8) NOT NULL,
#  `data_cretn_hhmm` varchar(4) NOT NULL,
#  `fndt_asst_items_cd` varchar(30) NOT NULL,
#  `smlr_ptim_ymd` varchar(8) NOT NULL,
#  `smlr_ptim_score` double(24,8) DEFAULT NULL,
#  PRIMARY KEY (`base_ymd`, `data_cretn_ymd`, `data_cretn_hhmm`, `fndt_asst_items_cd`, `smlr_ptim_ymd` )
#) ENGINE=InnoDB DEFAULT CHARSET=utf8
#;

/*---------------------------------------------
-- ������Ʈ��: `dscd`.`TMDAMD302`
-- �������� : 2021-02-10 05:43:14.0
-- ����: VALID
---------------------------------------------*/
CREATE TABLE `test_crud`.`TMDAMD302`
(
    `base_ymd`            varchar(8)    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '?????',
    `data_cretn_ymd`      varchar(8)    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '????????',
    `data_cretn_hhmm`     varchar(4)    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '???????',
    `fndt_asst_items_cd`  varchar(30)   CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '????????',
    `smlr_ptim_ymd`       varchar(8)    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '???????',
    `smlr_ptim_score`     double(24,8)  NOT NULL COMMENT '???????',
    `sys_last_pgm_id`     varchar(50)   CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '?????????ID',
    `sys_last_uno`        varchar(7)    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '??????????',
    `sys_last_regi_yms`   varchar(20)   CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '?????????',
    `sys_last_prcss_yms`  varchar(20)   CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '?????????',
    PRIMARY KEY (`base_ymd`, `data_cretn_ymd`, `data_cretn_hhmm`, `fndt_asst_items_cd`, `smlr_ptim_ymd`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=Dynamic COMMENT='TMD_?????????';



SELECT
A.*
FROM TMDAMD300 A	-- ���� ���̺�
ORDER BY A.DATA_CRETN_YMD DESC, A.DATA_CRETN_HHMM
;

SELECT
A.*
FROM TMDAMD301 A	-- ���� ���̺�
ORDER BY A.DATA_CRETN_YMD DESC
;



SELECT
A.*
FROM TMDAMD302 A
WHERE 1=1
AND A.FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND A.DATA_CRETN_YMD = '20201112'
AND A.DATA_CRETN_HHMM = '1525'

AND SMLR_PTIM_YMD >= '20151001'
AND SMLR_PTIM_YMD <= '20201112'
AND SMLR_PTIM_SCORE >= 4.768
AND SMLR_PTIM_SCORE <= 100
ORDER BY A.SMLR_PTIM_SCORE  -- , A.SMLR_PTIM_YMD DESC
;




ORDER BY A.SMLR_PTIM_SCORE DESC -- , A.SMLR_PTIM_YMD DESC



SELECT * FROM TMDAMDTMP;




INSERT INTO TMDAMDTMP
(
	 PROCKEY
	,INSSEQ
	,BASE_YMD
	,DATA_CRETN_YMD
	,DATA_CRETN_HHMM
	,CLSNGPRC
	,FNDT_ASST_ITEMS_CD
)
SELECT
	'AAAAAAAA',
	(SELECT (IFNULL(MAX(X.INSSEQ), 0) + 1)
		FROM TMDAMDTMP X
		WHERE 1=1
		AND X.PROCKEY = 'AAAAAAAAAAA'
	),
	'20160627',
	DATA_CRETN_YMD,
	DATA_CRETN_HHMM,
	CLSNGPRC,
	'KTB10YF'
FROM TMDAMD300 A		-- ���� ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND DATA_CRETN_YMD = '20160627';







-- ������ �м� ��¥ �� �ð�
SELECT
	MAX(DATA_CRETN_YMD) AS DATA_CRETN_YMD,
	MAX(DATA_CRETN_HHMM) AS DATA_CRETN_HHMM
FROM TMDAMD302		-- DATE / SCORE ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND CONCAT(DATA_CRETN_YMD, DATA_CRETN_HHMM) <= CONCAT('20201112', '1530')
;


SELECT
A.*
FROM TMDAMD302 A	-- DATE / SCORE ���
WHERE 1=1
AND A.FNDT_ASST_ITEMS_CD = 'KTB10YF'
ORDER BY A.DATA_CRETN_YMD DESC, A.DATA_CRETN_HHMM DESC, A.SMLR_PTIM_SCORE DESC
;

-- ������ ��� -1�� ��������
SELECT
	MAX(DATA_CRETN_YMD) AS PREV_1
FROM TMDAMD301	-- ���� ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND DATA_CRETN_YMD < '20201112'
;

-- ������ ��� -2�� ��������
SELECT
	MAX(DATA_CRETN_YMD) AS PREV_2
FROM TMDAMD301	-- ���� ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND DATA_CRETN_YMD < '20201110'
;

-- ������ ��� +1�� ��������
SELECT
	MIN(DATA_CRETN_YMD) AS NEXT_1
FROM TMDAMD301		-- ���� ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND DATA_CRETN_YMD > '20201112'
;

-- ������ ��� +2�� ��������
SELECT
	MIN(DATA_CRETN_YMD) AS NEXT_2
FROM TMDAMD301		-- ���� ���̺�
WHERE 1=1
AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND DATA_CRETN_YMD > '20201114'
;





-- set sql_safe_updates=0;
-- UPDATE TMDAMDTMP SET
-- 	DATA_CRETN_HHMM = '0930'
-- WHERE 1=1
-- AND DATA_CRETN_HHMM = '930'
-- ;






 

DROP TABLE `test_crud`.`tmdamdtmp`;

CREATE TABLE `TMDAMDTMP` (
  `prockey` varchar(30),
  `insseq` int(5),
  `base_ymd` varchar(8),
  `data_cretn_ymd` varchar(8),
  `data_cretn_hhmm` varchar(4),
  `clsngprc` double(24,8),
  `fndt_asst_items_cd` varchar(30)
  -- PRIMARY KEY (`base_ymd`, `data_cretn_ymd`, `data_cretn_hhmm`, `clsngprc`, `fndt_asst_items_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- INSERT INTO TMDAMDTMP SELECT * FROM TMDAMD303;
-- DELETE FROM TMDAMDTMP;



CREATE TABLE `LOGTABLE` (
  `ID` INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `LOG` varchar(4000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;







-- ���� ��� ���̺� (�ӽ÷� ����)
SELECT
-- '20201112' AS STD_DATE,
A.BASE_YMD AS STD_DATE,
A.DATA_CRETN_YMD AS REF_DATE,
A.DATA_CRETN_HHMM AS REF_TIME,
A.CLSNGPRC AS CLOSE_PRICE
FROM TMDAMDTMP A
WHERE 1=1
ORDER BY A.BASE_YMD DESC, A.DATA_CRETN_YMD, A.DATA_CRETN_HHMM
;

SELECT
	PROCKEY,
    INSSEQ,
	BASE_YMD AS STD_DATE,
	DATA_CRETN_YMD AS REF_DATE,
	DATA_CRETN_HHMM AS REF_TIME,
	CLSNGPRC AS CLOSE_PRICE,
    FNDT_ASST_ITEMS_CD AS ASSET
FROM TMDAMDTMP
WHERE 1=1
-- AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
-- AND DATA_CRETN_YMD = '20201108'
;


-- CALL CountOrderByStatus('Shipped', @total);
-- SELECT @total;

-- INOUT	P_PROCKEY	VARCHAR(30),
-- IN		P_ASSET		VARCHAR(30),
-- IN		P_SRCHDATE	VARCHAR(8),
-- IN		P_SRCHTIME	VARCHAR(4),
-- IN		P_PREV_DAY	INT,
-- IN		P_NEXT_DAY	INT,
-- OUT 	P_ERRDS		VARCHAR(50),
-- OUT 	P_RTNGN		VARCHAR(50)
-- CALL SP_CD_DASH_INPUT_INSERT(@'20210204104800000', 'KS200', '20201112', '1530', @P_ERRDS, @P_RTNGN);	-- KTB10YF / KS200
-- CALL SP_CD_DASH_INPUT_INSERT(@P_PROCKEY, 'KTB10YF', '20201112', '1530', @P_ERRDS, @P_RTNGN);	-- KTB10YF / KS200
-- CALL SP_CD_DASH_INPUT_INSERT(@P_PROCKEY, 'KTB10YF', '20201112', '1530', 2, 2, @P_ERRDS, @P_RTNGN);	-- KTB10YF / KS200
SET @P_PROCKEY = 2021020613303012345;
CALL SP_CD_DASH_INPUT_INSERT(@P_PROCKEY, 'KTB10YF', '20201112', '1530', 2, 2);	-- KTB10YF / KS200

-- SELECT @P_ERRDS, @P_RTNGN;
SELECT @P_PROCKEY;



DELETE FROM LOGTABLE;

SELECT
A.*
FROM LOGTABLE A
WHERE 1=1
ORDER BY A.ID
;



DELETE FROM TMDAMDTMP;

-- ���� ���
SELECT
A.*
FROM TMDAMDTMP A
WHERE 1=1
ORDER BY A.PROCKEY, A.INSSEQ, A.BASE_YMD, A.DATA_CRETN_YMD, A.DATA_CRETN_HHMM
;







/* ���� ��� ���� */
SELECT
	A.STD_DATE,
	A.REF_DATE,
	GROUP_CONCAT(A.REF_TIME SEPARATOR ',') AS REF_TIME,
	GROUP_CONCAT(A.CLOSE_PRICE SEPARATOR ',') AS CLOSE_PRICE
FROM
(
	SELECT
		BASE_YMD AS STD_DATE,
		DATA_CRETN_YMD AS REF_DATE,
		DATA_CRETN_HHMM AS REF_TIME,
		CLSNGPRC AS CLOSE_PRICE
	FROM TMDAMDTMP
	WHERE 1=1
	AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
	AND DATA_CRETN_YMD = '20201108'
	UNION ALL
	SELECT
		BASE_YMD AS STD_DATE,
		DATA_CRETN_YMD AS REF_DATE,
		DATA_CRETN_HHMM AS REF_TIME,
		CLSNGPRC AS CLOSE_PRICE
	FROM TMDAMDTMP
	WHERE 1=1
	AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
	AND DATA_CRETN_YMD = '20201110'
	UNION ALL
	SELECT
		BASE_YMD AS STD_DATE,
		DATA_CRETN_YMD AS REF_DATE,
		DATA_CRETN_HHMM AS REF_TIME,
		CLSNGPRC AS CLOSE_PRICE
	FROM TMDAMDTMP
	WHERE 1=1
	AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
	AND DATA_CRETN_YMD = '20201112'
	UNION ALL
	SELECT
		BASE_YMD AS STD_DATE,
		DATA_CRETN_YMD AS REF_DATE,
		DATA_CRETN_HHMM AS REF_TIME,
		CLSNGPRC AS CLOSE_PRICE
	FROM TMDAMDTMP
	WHERE 1=1
	AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
	AND DATA_CRETN_YMD = '20201114'
	UNION ALL
	SELECT
		BASE_YMD AS STD_DATE,
		DATA_CRETN_YMD AS REF_DATE,
		DATA_CRETN_HHMM AS REF_TIME,
		CLSNGPRC AS CLOSE_PRICE
	FROM TMDAMDTMP
	WHERE 1=1
	AND FNDT_ASST_ITEMS_CD = 'KTB10YF'
	AND DATA_CRETN_YMD = '20201116'
) A
WHERE 1=1
GROUP BY A.STD_DATE, A.REF_DATE
ORDER BY A.STD_DATE DESC, A.REF_DATE, CAST(A.REF_TIME AS UNSIGNED)
;









/* ���� ��� */
SELECT
	AA.PROCKEY,
	AA.STD_DATE,
	AA.REF_DATE,
	CONCAT('"', AA.REF_TIME2, '"') AS REF_TIME,
	CONCAT('"', AA.CLOSE_PRICE2, '"') AS CLOSE_PRICE
FROM
(
	SELECT
		A.PROCKEY,
		A.STD_DATE,
		A.REF_DATE,
-- 		GROUP_CONCAT(A.REF_TIME SEPARATOR ',') AS REF_TIME,
-- 		GROUP_CONCAT(A.CLOSE_PRICE SEPARATOR ',') AS CLOSE_PRICE
		GROUP_CONCAT(A.REF_TIME SEPARATOR '","') AS REF_TIME2,
		GROUP_CONCAT(A.CLOSE_PRICE SEPARATOR '","') AS CLOSE_PRICE2
	FROM
	(
		SELECT
			A.PROCKEY,
			A.INSSEQ,
			A.BASE_YMD AS STD_DATE,
			A.DATA_CRETN_YMD AS REF_DATE,
			A.DATA_CRETN_HHMM AS REF_TIME,
			A.CLSNGPRC AS CLOSE_PRICE
		FROM TMDAMDTMP A
		WHERE 1=1
		AND A.PROCKEY = '2021020613303012345'
		ORDER BY A.PROCKEY, A.INSSEQ
	) A
	WHERE 1=1
	GROUP BY A.PROCKEY, A.STD_DATE, A.REF_DATE
	ORDER BY A.PROCKEY, A.INSSEQ, A.STD_DATE, A.REF_DATE, A.REF_TIME
) AA
WHERE 1=1
;




SELECT
-- 	A.SMLR_PTIM_YMD,
-- 	A.SMLR_PTIM_SCORE
	GROUP_CONCAT(A.SMLR_PTIM_YMD ORDER BY A.SMLR_PTIM_SCORE DESC SEPARATOR ',') AS DATE,
	GROUP_CONCAT(A.SMLR_PTIM_SCORE ORDER BY A.SMLR_PTIM_SCORE DESC SEPARATOR ',') AS SCORE
FROM TMDAMD302 A		-- DATE / SCORE ���̺�
WHERE 1=1
AND A.FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND A.DATA_CRETN_YMD = '20201112'
AND A.DATA_CRETN_HHMM = '1525'
ORDER BY A.SMLR_PTIM_SCORE DESC
;













CREATE TABLE emp (
   empno INT,
   ename VARCHAR(30),
   job VARCHAR(30),
   sal INT
)ENGINE=INNODB DEFAULT CHAR SET=UTF8;

INSERT INTO emp
VALUES
(7902,'FORD','ANALYST',3000),
(7788,'SCOTT','ANALYST',3000),
(7369,'SMITH','CLERK',800),
(7900,'JAMES','CLERK',950),
(7876,'ADAMS','CLERK',1100),
(7934,'MILLER','CLERK',1300),
(7782,'CLARK','MANAGER',2450),
(7698,'BLAKE','MANAGER',2850),
(7566,'JONES','MANAGER',2975),
(7839,'KING','PRESIDENT',5000),
(7654,'MARTIN','SALESMAN',1250),
(7521,'WARD','SALESMAN',1250),
(7844,'TURNER','SALESMAN',1500),
(7499,'ALLEN','SALESMAN',1600);





SELECT empno, ename, job, sal, rnum
FROM (
   SELECT a.*, 
           (CASE @vjob WHEN a.job THEN @rownum:=@rownum+1 ELSE @rownum:=1 END) rnum,
           (@vjob:=a.job) vjob
   FROM emp a, (SELECT @vjob:='', @rownum:=0 FROM DUAL) b
   ORDER BY a.job, a.sal                 
) c;




-- DASHBOARD DATA ���̺�
#CREATE TABLE `test_crud`.`TMDAMD999` (
#  `asset` varchar(30),
#  `date` varchar(8),
#  `time` varchar(4),
#  `date_sim` varchar(8),
#  `date_chart` varchar(8),
#  `time_chart` varchar(4),
#  `xvalue` double(10,2),
#  `yvalue_n` double(10,2),
#  `yvalue_c` double(10,2)
#) ENGINE=InnoDB DEFAULT CHARSET=utf8
#;

#ALTER TABLE `test_crud`.`TMDAMD999` CHANGE data date varchar(8);




#�����ڻ�	������	���ؽð�	���籹�鳯¥	��Ʈ ��¥(-2,+2)	��Ʈ �ð�	��Ʈ x��	��Ʈ y��(�������)	��Ʈ y��(������������)
#asset		date	time		date_sim		date_chart			time_chart	xvalue		yvalue_n			yvalue_c

-- DATE / SCORE ���
SELECT
A.*
FROM TMDAMD302 A
WHERE 1=1
AND A.FNDT_ASST_ITEMS_CD = 'KTB10YF'
AND A.DATA_CRETN_YMD = '20201014'
AND A.DATA_CRETN_HHMM = '1530'
ORDER BY A.SMLR_PTIM_SCORE DESC, A.SMLR_PTIM_YMD
;


SELECT
A.*
FROM TMDAMD999 A
WHERE 1=1
AND A.ASSET = 'KTB10YF'
AND A.DATE = '20201014'
AND A.TIME = '1530'
;


SELECT
A.*
FROM TMDAMD999 A, TMDAMD302 B
WHERE 1=1
AND A.ASSET = B.FNDT_ASST_ITEMS_CD
AND A.DATE = B.DATA_CRETN_YMD
AND A.TIME = B.DATA_CRETN_HHMM
AND A.date_sim = B.smlr_ptim_ymd
AND A.ASSET = 'KTB10YF'
AND A.DATE = '20201014'
AND A.TIME = '1530'
#ORDER BY A.ASSET, A.DATE, A.TIME, A.DATE_SIM, A.DATE_CHART, A.TIME_CHART
ORDER BY B.SMLR_PTIM_SCORE DESC, A.DATE_CHART
;










