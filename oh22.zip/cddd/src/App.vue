<template>
	<div>
		<!-- {{apiUrl}}<br />
		{{value}}<br />

		<button @click="add">add</button><br />
		<button @click.once="paramAdd('paramss!!')">paramAdd</button><br /><br /> -->

		<router-link to="/ficc">Go to FICC</router-link><br /><br />

		<!-- <router-link to="/page2">Go to page2</router-link><br /> -->
		<!-- <router-link to="/page3">Go to page3</router-link><br /> -->

		<router-link to="/testpage">Go to testpage</router-link><br />

		<!-- <router-link to="/sss">Go to Server Side Search</router-link><br /> -->
		<!-- <router-link to="/mft">Go to Multiple Filters Table</router-link><br /> -->

		<router-view></router-view>

		<!-- <h2>Full example</h2>
		<MultipleFiltersTable/> -->
	</div>
</template>

<script>
// import MultipleFiltersTable from '@/components/MultipleFiltersTable'

export default {
	name: "App",
	components: {
		// MultipleFiltersTable
	},
	data: () => ({
		apiUrl: process.env.VUE_APP_URL,
		value: 1
	}),
	methods: {
		add() {
			this.value = this.value + 1
		},
		paramAdd(param) {
			console.log(param)
		}
	},
};
</script>
