import axios from 'axios';

const api = {
    assetListURL: process.env.VUE_APP_URL,
    dateScoreListURL: process.env.VUE_APP_URL,
    caseResultListURL: process.env.VUE_APP_URL,
}


// axios.defaults.baseURL = 'http://localhost:8080';
axios.defaults.headers.post['Content-Type'] = 'application/json;charset=utf-8';
axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';


export const fetchAssetList = (reqParam) => {
    // console.log('>>>>> api > fetchAssetList    START <<<<<')
    // console.log('>>>>> api.assetListURL :::', api.assetListURL)
    // console.log('>>>>> reqParam :::', reqParam)

    // return axios.get(api.assetListURL);
    return axios.post('/api/movies/', {
        reqParam: reqParam,
    }, {
        withCredentials: true,
    }).then((res) => {
        console.log('res ::: ', res)
        return res
    }).catch((err) => {
        console.error('err ::: ', err);
    });
}

export const fetchDateScoreList = (reqParam) => {
    // console.log('>>>>> api > fetchDateScoreList    START <<<<<')
    // console.log('>>>>> api.dateScoreListURL :::', api.dateScoreListURL)
    // console.log('>>>>> reqParam :::', reqParam)

    // return axios.get(api.dateScoreListURL);

    // return axios.get('http://10.17.115.183:8082/api/formal_mp/DAM_FORMAL_MP_S01', reqParam, {
    // return axios.get('http://localhost:3000/api/movies/' + 1, {
    //         headers: {
    //             'Access-Control-Allow-Origin': '*',
    //             'Content-Type': 'application/json; charset = utf-8',
    //         },
    //     })
    //     .then((res, err) => {
    //         if (err) {
    //             console.log(err);
    //         } else {
    //             console.log(res);
    //         }
    //     });

    return axios.post('/api/movies/', {
        reqParam: reqParam, // body: { reqParam: { sendDateTime: '202102121952', asset: 'KTB3YF' } }
    }, {
        withCredentials: true,
    }).then((res) => {
        // console.log('res ::: ', res.status.code)
        console.log('res ::: ', res)
        return res
    }).catch((err) => {
        console.error('err ::: ', err);
    });
}

export const fetchCaseResultList = (reqParam) => {
    // console.log('>>>>> api > fetchCaseResultList    START <<<<<')
    // console.log('>>>>> api.caseResultListURL :::', api.caseResultListURL)
    // console.log('>>>>> reqParam :::', reqParam)

    return axios.post('/api/movies/', {
        reqParam: reqParam, // body: { reqParam: { sendDateTime: '202102121952', asset: 'KTB3YF' } }
    }, {
        withCredentials: true,
    }).then((res) => {
        console.log('res ::: ', res)
        return res
    }).catch((err) => {
        console.error('err ::: ', err);
    });
}
export const fetchCaseResultListTEST = (reqParam) => {
    // console.log('>>>>> api > fetchCaseResultList    START <<<<<')
    // console.log('>>>>> api.caseResultListURL :::', api.caseResultListURL)
    // console.log('>>>>> reqParam :::', reqParam)

    return axios.post('/api/movies/', {
        reqParam: reqParam, // body: { reqParam: { sendDateTime: '202102121952', asset: 'KTB3YF' } }
    }, {
        withCredentials: true,
    }).then((res) => {
        console.log('res ::: ', res)
        return res
    }).catch((err) => {
        console.error('err ::: ', err);
    });
}
export const fetchCaseResultListTEST2 = (reqParam) => {
    // console.log('>>>>> api > fetchCaseResultList    START <<<<<')
    // console.log('>>>>> api.caseResultListURL :::', api.caseResultListURL)
    // console.log('>>>>> reqParam :::', reqParam)

    return axios.post('/api/movies/', {
        reqParam: reqParam, // body: { reqParam: { sendDateTime: '202102121952', asset: 'KTB3YF' } }
    }, {
        withCredentials: true,
    }).then((res) => {
        console.log('res ::: ', res)
        return res
    }).catch((err) => {
        console.error('err ::: ', err);
    });
}