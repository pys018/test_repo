export const offsetSelected = 'N'
export const offsetOptions = [
    { text: 'Now Price', value: 'N' },
    { text: 'Close Price', value: 'C' }
]

export const refreshSelected = '30'
export const refreshOptions = [
    { text: 'Refresh 5min', value: '5' },
    { text: 'Refresh 10min', value: '10' },
    { text: 'Refresh 30min', value: '30' },
    { text: 'Refresh 60min', value: '60' },
]

export const xaxisUnitSelected = '30'
export const xaxisUnitOptions = [
    { text: '5min', value: '5' },
    { text: '10min', value: '10' },
    { text: '30min', value: '30' },
    { text: '60min', value: '60' },
    { text: '1day', value: '1D' },
]

export const ficcYaxisPriceSelected = 'P'
export const equityYaxisPriceSelected = 'Y'
export const yaxisPriceOptions = [
    { text: '가격차이', value: 'P' },
    { text: '수익율', value: 'Y' },
]

export const dateScoreHeaders = [{
        text: 'DATE',
        sortable: true,
        value: 'dateVal',
    },
    {
        text: 'Score',
        sortable: true,
        value: 'scoreVal',
    },
]

// export const numFilterSelected = {
//     value: '<'
// }
export const numFilterSelected = '<'
export const numFilterOptions = [
    { text: '< (Is less than)', value: '<' },
    { text: '≤ (Is less than or equal to)', value: '<=' },
    { text: '＞(Is greater than)', value: '>' },
    { text: '≥ (Is greater than or equal to)', value: '>=' },
]

export const filterEditorDatePrefix = '[DATE] '
export const filterEditorScorePrefix = '[Score] '
export const filterEditorMiddle = [
    { text: 'Is less than ' },
    { text: 'Is less than or equal to ' },
    { text: 'Is greater than ' },
    { text: 'Is greater than or equal to ' },
]

export const caseResultHeaders = [{
        text: 'Category',
        align: 'start',
        sortable: false,
        value: 'resultCategoryVal',
    },
    {
        text: '0D+1H',
        sortable: false,
        value: 'result0D1HVal',
    },
    {
        text: '0D+2H',
        sortable: false,
        value: 'result0D2HVal',
    },
    {
        text: '0D+3H',
        sortable: false,
        value: 'result0D3HVal',
    },
    {
        text: '0D+4H',
        sortable: false,
        value: 'result0D4HVal',
    },
    {
        text: '0D+5H',
        sortable: false,
        value: 'result0D5HVal',
    },
    {
        text: '0D+6H',
        sortable: false,
        value: 'result0D6HVal',
    },
    {
        text: '1D+0H',
        sortable: false,
        value: 'result1D0HVal',
    },
    {
        text: '2D+0H',
        sortable: false,
        value: 'result2D0HVal',
    },
]