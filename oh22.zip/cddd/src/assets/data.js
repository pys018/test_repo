export const ficcAssetOptionsData = [
    { text: 'KTB3YF', value: 'KTB3YF' },
    { text: 'KTB10YF', value: 'KTB10YF' },
    { text: 'UST2YF', value: 'UST2YF' },
    { text: 'UST5YF', value: 'UST5YF' },
    { text: 'UST10YF', value: 'UST10YF' },
    { text: 'USDKRWF', value: 'USDKRWF' },
    { text: 'EURKRWF', value: 'EURKRWF' },
    { text: 'JPYKRWF', value: 'JPYKRWF' },
]

// export const ficcDateScoreListData = [{
//         dateVal: '20201112',
//         scoreVal: 100,
//     },
//     {
//         dateVal: '20190711',
//         scoreVal: 23.66,
//     },
//     {
//         dateVal: '20160627',
//         scoreVal: 23.49,
//     },
//     {
//         dateVal: '20150703',
//         scoreVal: 19.04,
//     },
//     {
//         dateVal: '20190628',
//         scoreVal: 16.38,
//     },
//     {
//         dateVal: '20191015',
//         scoreVal: 15.2,
//     },
//     {
//         dateVal: '20170206',
//         scoreVal: 13.13,
//     },
//     {
//         dateVal: '20171103',
//         scoreVal: 12.46,
//     },
//     {
//         dateVal: '20190807',
//         scoreVal: 10.48,
//     },
//     {
//         dateVal: '20180626',
//         scoreVal: 9.64,
//     },
//     {
//         dateVal: '20200128',
//         scoreVal: 8.78,
//     },
//     {
//         dateVal: '20201007',
//         scoreVal: 6.76,
//     },
//     {
//         dateVal: '20170712',
//         scoreVal: 5.25,
//     },
//     {
//         dateVal: '20160913',
//         scoreVal: 4.74,
//     },
//     {
//         dateVal: '20151124',
//         scoreVal: 3.95,
//     },
//     {
//         dateVal: '20170824',
//         scoreVal: 2.67,
//     },
//     {
//         dateVal: '20191031',
//         scoreVal: 0.8,
//     },
//     {
//         dateVal: '20150224',
//         scoreVal: 0.76,
//     },
// ]
export const ficcDateScoreListData = [{
        dateVal: '20-11-12',
        scoreVal: 100,
    },
    {
        dateVal: '19-07-11',
        scoreVal: 23.66,
    },
    {
        dateVal: '16-06-27',
        scoreVal: 23.49,
    },
    {
        dateVal: '15-07-03',
        scoreVal: 19.04,
    },
    {
        dateVal: '19-06-28',
        scoreVal: 16.38,
    },
    {
        dateVal: '19-10-15',
        scoreVal: 15.2,
    },
    {
        dateVal: '17-02-06',
        scoreVal: 13.13,
    },
    {
        dateVal: '17-11-03',
        scoreVal: 12.46,
    },
    {
        dateVal: '19-08-07',
        scoreVal: 10.48,
    },
    {
        dateVal: '18-06-26',
        scoreVal: 9.64,
    },
    {
        dateVal: '20-01-28',
        scoreVal: 8.78,
    },
    {
        dateVal: '20-10-07',
        scoreVal: 6.76,
    },
    {
        dateVal: '17-07-12',
        scoreVal: 5.25,
    },
    {
        dateVal: '16-09-13',
        scoreVal: 4.74,
    },
    {
        dateVal: '15-11-24',
        scoreVal: 3.95,
    },
    {
        dateVal: '17-08-24',
        scoreVal: 2.67,
    },
    {
        dateVal: '19-10-31',
        scoreVal: 0.8,
    },
    {
        dateVal: '15-02-24',
        scoreVal: 0.76,
    },
]

export const ficcCaseResultListData = [{
        resultCategoryVal: 'CASE UP',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '49.95',
        result2D0HVal: '54.13',
    },
    {
        resultCategoryVal: 'CASE DOWN',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '50.04',
        result2D0HVal: '45.86',
    },
]

// export const ORG_ficcCaseResultListDataTest = [{
//         resultCategoryVal: 'CASE UP',
//         result0D1HVal: '-',
//         result0D2HVal: '-',
//         result0D3HVal: '-',
//         result0D4HVal: '-',
//         result0D5HVal: '-',
//         result0D6HVal: '-',
//         result1D0HVal: '51',
//         result2D0HVal: '49',
//     },
//     {
//         resultCategoryVal: 'CASE DOWN',
//         result0D1HVal: '-',
//         result0D2HVal: '-',
//         result0D3HVal: '-',
//         result0D4HVal: '-',
//         result0D5HVal: '-',
//         result0D6HVal: '-',
//         result1D0HVal: '49',
//         result2D0HVal: '51',
//     },
// ]
export const ficcCaseResultListDataTest = [{
        resultCategoryVal: 'CASE UP',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '49.95',
        result2D0HVal: '49',
    },
    {
        resultCategoryVal: 'CASE DOWN',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '50.04',
        result2D0HVal: '51',
    },
]
export const ficcCaseResultListDataTest2 = [{
        resultCategoryVal: 'CASE UP',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '51',
        result2D0HVal: '54.13',
    },
    {
        resultCategoryVal: 'CASE DOWN',
        result0D1HVal: '-',
        result0D2HVal: '-',
        result0D3HVal: '-',
        result0D4HVal: '-',
        result0D5HVal: '-',
        result0D6HVal: '-',
        result1D0HVal: '49',
        result2D0HVal: '45.86',
    },
]