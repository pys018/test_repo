<template>
	<div class="text-center"
		v-if="visibleCR" @click.self="handleWrapperClick"><!-- dialog / visibleCR -->
		<v-dialog
			v-model="visibleCR"
			width="400">
			<!-- <template v-slot:activator="{ on, attrs }">
				<v-btn
					color="red lighten-2"
					dark
					v-bind="attrs"
					v-on="on">
					Case 분석 국면전환
				</v-btn>
			</template> -->

			<v-card>
				<v-card-title class="headline grey lighten-2">
					Case 분석 국면전환
					<v-spacer/>
					<button @click="$emit('update:visibleCR', !visibleCR)">X</button>
				</v-card-title>

				<v-divider/>

				<v-container class="grey lighten-5">
					<v-row no-gutters>
						<div v-html="caseResultAlertTxt"></div>
					</v-row>
				</v-container>

				<v-divider/>

				<v-card-actions>
					<v-btn
						color="primary"
						text
						@click="$emit('update:visibleCR', !visibleCR)">
						확인
					</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</div>
</template>

<script>
export default {
	name: 'CaseResultPop',
	data() {
		return {
			//dialog: false,
		};
	},
	props: {
		visibleCR: {
			type: Boolean,
			require: true,
			default: false
		},
		caseResultAlertTxt: String
	},
	mounted() {
		
	},
	methods: {
		handleWrapperClick() {
			this.$emit('update:visibleCR', false)
		},
	},
};
</script>

<style lang="scss" scoped>
.keywordColor {
	color: red;
}
.tickerColor {
	color: green;
}
</style>