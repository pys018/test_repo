<template>
	<div class="my-modal"
		v-if="visibleDF" @click.self="handleWrapperClick">
		<div class="my-modal__dialog">
			<header class="my-modal__header">
				<span>{{title}}</span>
				<button @click="$emit('update:visibleDF', !visibleDF)">Close</button>
			</header>
			<div class="my-modal__body">
				<slot>
					<v-tabs v-model="activeTab" class="tabs">
						<v-tabs-slider color="teal lighten-3"></v-tabs-slider>
						<v-tab
							:key="'valuesTab'">
							Values
						</v-tab>
						<v-tab
							:key="'numericTab'">
							Numeric Filters
						</v-tab>
					</v-tabs>

					<v-tabs-items v-model="activeTab" class="tabs">
						<v-tab-item
							:key="'valuesTab'">
							From
							<v-text-field
								v-mask="'##-##-##'"
								v-model="filterFromDate"
								label=""
								persistent-hint
								placeholder="YY-MM-DD"
							></v-text-field>
							~
							To
							<v-text-field
								v-mask="'##-##-##'"
								v-model="filterToDate"
								label=""
								persistent-hint
								placeholder="YY-MM-DD"
							></v-text-field>

							<button @click.stop="resetFilterData('values')">초기화</button>
							<button @click.stop="runFilter('values')">실행</button>
						</v-tab-item>
						<v-tab-item
							:key="'numericTab'">
							<v-select
								v-model="numFilterSelected"
								:items="numFilterOptions"
								label=""
							></v-select>

							<v-autocomplete
								v-model="filterNumbericDate"
								:items="ficcDateNumFilterList"
								label="Select a value"
								chips
								color="blue"
							>
							</v-autocomplete>

							<button @click.stop="resetFilterData('numberic')">초기화</button>
							<button @click.stop="runFilter('numberic')">실행</button>
						</v-tab-item>
					</v-tabs-items>
				</slot>
			</div>
		</div>
	</div>
</template>

<script>
import { constant, getDateAndTime } from '../mixin/index'
import { mapGetters } from 'vuex'

export default {
	name: 'DateFilterPop',

    components: {

    },

    data() {
        return {
			activeTab: 'valuesTab',

			//filterNumbericDate: '',

			dateFilterData: {
				filterType: '',
				filterFromDate: '',
				filterToDate: '',
				numFilterSelected: '',
				filterNumbericDate: '',
			},
        };
    },

    mixins: [constant, getDateAndTime],

    computed: {
		...mapGetters('ficcStore', [
			'ficcDateFilterList',
			'ficcScoreFilterList',
			'ficcDateNumFilterList',
		]),

        filterFromDate: {
            get() {
                return this.dateFilterData.filterFromDate
            },
            set (value) {
				this.dateFilterData.filterFromDate = value
            }
        },
        filterToDate: {
            get() {
                return this.dateFilterData.filterToDate
            },
            set (value) {
				this.dateFilterData.filterToDate = value
            }
        },
        numFilterSelected: {
            get() {
                return this.dateFilterData.numFilterSelected
            },
            set (value) {
				this.dateFilterData.numFilterSelected = value
            }
        },
        filterNumbericDate: {
            get() {
                return this.dateFilterData.filterNumbericDate
            },
            set (value) {
				this.dateFilterData.filterNumbericDate = value
            }
        },
	},

	props: {
		visibleDF: {
			type: Boolean,
			require: true,
			default: false
		},
		title: {
			type: String,
			require: false,
		},
	},

	created() {

    },

	mounted() {

    },

	methods: {
		handleWrapperClick() {
			this.$emit('update:visibleDF', false)
		},

		initData() {
			let lfrDate = this.dateFilterData.filterFromDate
			let ltoDate = this.dateFilterData.filterToDate
			console.log('>>>>> lfrDate ::: ', lfrDate)
			console.log('>>>>> ltoDate ::: ', ltoDate)

			if(lfrDate == '' && ltoDate == '') {
				this.dateFilterData.filterFromDate = this.ficcDateFilterList[0]
				this.dateFilterData.filterToDate = this.ficcDateFilterList[this.ficcDateFilterList.length - 1];
				console.log('>>>>> this.dateFilterData.filterFromDate ::: IIIII ::: ', this.dateFilterData.filterFromDate)
				console.log('>>>>> this.dateFilterData.filterToDate ::: IIIII ::: ', this.dateFilterData.filterToDate)
			}

			let lnumFilterSelected = this.dateFilterData.numFilterSelected
			console.log('>>>>> lnumFilterSelected ::: ', lnumFilterSelected)
			if(lnumFilterSelected == '' || lnumFilterSelected == null) {
				this.dateFilterData.numFilterSelected = '<'
			}
		},

        runFilter(filterType) {
			// Values Filter인 경우
			let lfrDate = this.filterFromDate
			let ltoDate = this.filterToDate
			if(filterType == 'values') {
				if(lfrDate == null || lfrDate == '' || lfrDate == 'undefined' || ltoDate == null || ltoDate == '' || ltoDate == 'undefined') {
					return;
				}

				lfrDate = this.filterFromDate.replace(/-/g,'')
				if(lfrDate == null || lfrDate == '' || lfrDate.length != 6) {
					alert("날짜 형식을 확인해주세요.")
					return;
				}

				ltoDate = this.filterToDate.replace(/-/g,'')
				if(ltoDate == null || ltoDate == '' || ltoDate.length != 6) {
					alert("날짜 형식을 확인해주세요.")
					return;
				}
			}

			// Numberic Filter인 경우는 선택한 값 체크하기
			let lfilterNumbericDate = ''
			if(filterType == 'numberic') {
				lfilterNumbericDate = this.filterNumbericDate.replace(/-/g,'')
				console.log('>>>>> lfilterNumbericDate ::: ', lfilterNumbericDate)

				if(lfilterNumbericDate == null || lfilterNumbericDate == '' || lfilterNumbericDate == 'undefined') {
					alert("날짜를 선택해주세요.")
					return;
				}
			}

			console.log('>>>>> runFilter >>>>> this.dateFilterData ::: ', this.dateFilterData)
			console.log('>>>>> runFilter >>>>> this.numFilterSelected ::: ', this.numFilterSelected)

			this.dateFilterData.filterType = filterType

			this.dateFilterData.numFilterSelected = this.numFilterSelected
			this.dateFilterData.filterNumbericDate = lfilterNumbericDate


            const currentFilterData = this.dateFilterData
			console.log('>>>>> currentFilterData ::: ', currentFilterData)

            this.$emit('_run-datefilter', currentFilterData)

			this.handleWrapperClick()
        },

		resetFilterData(filterType) {

			let lfrDate = this.filterFromDate
			let ltoDate = this.filterToDate
			if(lfrDate == null || lfrDate == '' || lfrDate == 'undefined' || ltoDate == null || ltoDate == '' || ltoDate == 'undefined') {
				return;
			}

			// Values Filter인 경우
			//if(filterType == 'values') {
				this.dateFilterData.filterType = ''
				this.dateFilterData.filterFromDate = ''
				this.dateFilterData.filterToDate = ''
				this.dateFilterData.numFilterSelected = '<'
				this.dateFilterData.filterNumbericDate = null
				console.log('>>>>> resetFilterData ::: this.dateFilterData ::: ', this.dateFilterData)

				// DATE 포맷이 변경되면서 수정
				// this.dateFilterData.filterFromDate = this.to_date_format(this.ficcDateFilterList[0], '-')
				// this.dateFilterData.filterToDate = this.to_date_format(this.ficcDateFilterList[this.ficcDateFilterList.length - 1], '-')
				this.dateFilterData.filterFromDate = this.ficcDateFilterList[0]
				this.dateFilterData.filterToDate = this.ficcDateFilterList[this.ficcDateFilterList.length - 1]
			//}

			// Numberic Filter인 경우
			// if(filterType == 'numberic') {

			// }

			// 메인화면 데이타 필터 해제
			this.$emit('_reset-datefilter')
		},

		to_date_format(date_str, gubun) {
			var yyMMdd = String(date_str);
			var sYear = yyMMdd.substring(0,2);
			var sMonth = yyMMdd.substring(2,4);
			var sDate = yyMMdd.substring(4,6);

			return sYear + gubun + sMonth + gubun + sDate;
		},
	},
}
</script>

<style lang="scss">
$module: 'my-modal';
.#{$module} {
	// This is modal bg
	background-color: rgba(0,0,0,.7);
	top: 0; right: 0; bottom: 0; left: 0;
	position: fixed;
	overflow: auto;
	margin: 0;
	//This is modal layer
	&__dialog{
		left: 70%;
		top: 175px;
		width: 500px;
		position: absolute;
		background: #fff;
		margin-bottom: 50px;
	}
	&__header {
		font-size: 28px;
		font-weight: bold;
		line-height: 1.29;
		padding: 16px 16px 0 25px;
		position: relative;
	}
	&__body {
		padding: 25px;
		min-height: 150px;
		max-height: 412px;
		overflow-y: scroll;
	}
}
</style>