<template>
	<div class="my-modal"
		v-if="visibleFE" @click.self="handleWrapperClick">
		<div class="my-modal__dialog">
			<header class="my-modal__header">
				<span>{{title}}</span>
				<button @click="$emit('update:visibleFE', !visibleFE)">Close</button>
			</header>

			<v-divider></v-divider>

			<div class="my-modal__body">
				<v-simple-table dense border="1" v-if="filterEditorTxt.dateFiltered">
					<tbody>
						<tr v-if="filterEditorTxt.dateFilterType == 'values'">
							<td>{{filterEditorTxt.dateFromValuesTxt}}</td>
							<td rowspan="2">
								<button @click.stop="resetFilterData('date')">
									X
								</button>
							</td>
						</tr>
						<tr v-if="filterEditorTxt.dateFilterType == 'values'">
							<td>{{filterEditorTxt.dateToValuesTxt}}</td>
							<td></td>
						</tr>
						<tr v-if="filterEditorTxt.dateFilterType == 'numberic'">
							<td>{{filterEditorTxt.dateNumbericTxt}}</td>
							<td>
								<button @click.stop="resetFilterData('date')">
									X
								</button>
							</td>
						</tr>
					</tbody>
				</v-simple-table>

				<v-simple-table dense border="1" v-if="filterEditorTxt.scoreFiltered">
					<tbody>
						<tr v-if="filterEditorTxt.scoreFilterType == 'values'">
							<td>{{filterEditorTxt.scoreFromValuesTxt}}</td>
							<td rowspan="2">
								<button @click.stop="resetFilterData('score')">
									X
								</button>
							</td>
						</tr>
						<tr v-if="filterEditorTxt.scoreFilterType == 'values'">
							<td>{{filterEditorTxt.scoreToValuesTxt}}</td>
							<td></td>
						</tr>
						<tr v-if="filterEditorTxt.scoreFilterType == 'numberic'">
							<td>{{filterEditorTxt.scoreNumbericTxt}}</td>
							<td>
								<button @click.stop="resetFilterData('score')">
									X
								</button>
							</td>
						</tr>
					</tbody>
				</v-simple-table>

				<v-divider></v-divider>

				<button
					@click.stop="resetFilterData('all')"
				>
					초기화
				</button>
				<button
					@click.stop="runFilter('all')"
					:disabled="filterEditorTxt.dateFiltered == false && filterEditorTxt.scoreFiltered == false"
				>
					실행
				</button>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'FilterEditorPop',

    components: {

    },

    data() {
        return {

        };
    },

    computed: {

	},

	props: {
		visibleFE: {
			type: Boolean,
			require: true,
			default: false
		},
		title: {
			type: String,
			require: false,
		},
		filterEditorTxt: {
			type: Object,
			require: false,
		},
	},

	created() {

    },

	mounted() {

    },

	methods: {
		handleWrapperClick() {
			this.$emit('update:visibleFE', false)
		},

        runFilter(filterType) {
			this.handleWrapperClick()
        },

		// 메인화면 데이타 필터 해제
		resetFilterData(filterType) {
			if(filterType == 'date') {
				this.filterEditorTxt.dateFiltered = false

				this.$emit('_reset-datefilter')
			} else if(filterType == 'score') {
				this.filterEditorTxt.scoreFiltered = false

				this.$emit('_reset-scorefilter')
			} else if(filterType == 'all') {
				this.filterEditorTxt.dateFiltered = false
				this.filterEditorTxt.scoreFiltered = false

				this.$emit('_reset-datefilter')
				this.$emit('_reset-scorefilter')

				this.handleWrapperClick()
			}
		},
	},
}
</script>

<style lang="scss">
$module: 'my-modal';
.#{$module} {
	// This is modal bg
	background-color: rgba(0,0,0,.7);
	top: 0; right: 0; bottom: 0; left: 0;
	position: fixed;
	overflow: auto;
	margin: 0;
	//This is modal layer
	&__dialog{
		left: 70%;
		top: 175px;
		width: 500px;
		position: absolute;
		background: #fff;
		margin-bottom: 50px;
	}
	&__header {
		font-size: 28px;
		font-weight: bold;
		line-height: 1.29;
		padding: 16px 16px 0 25px;
		position: relative;
	}
	&__body {
		padding: 25px;
		min-height: 150px;
		max-height: 412px;
		overflow-y: scroll;
	}
}
</style>