<template>
	<div class="my-modal"
		v-if="visibleSF" @click.self="handleWrapperClick">
		<div class="my-modal__dialog">
			<header class="my-modal__header">
				<span>{{title}}</span>
				<button @click="$emit('update:visibleSF', !visibleSF)">Close</button>
			</header>
			<div class="my-modal__body">
				<slot>
					<v-tabs v-model="activeTab" class="tabs">
						<v-tabs-slider color="teal lighten-3"></v-tabs-slider>
						<v-tab
							:key="'valuesTab'">
							Values
						</v-tab>
						<v-tab
							:key="'numericTab'">
							Numeric Filters
						</v-tab>
					</v-tabs>

					<v-tabs-items v-model="activeTab" class="tabs">
						<v-tab-item
							:key="'valuesTab'">
							From
							<!-- <v-text-field
								v-model="filterFromScore"
								label=""
								persistent-hint
							></v-text-field> -->
							<input
								v-model="filterFromScore"
								type="text"
								maxlength="10"
								placeholder=""
								oninput="javascript: this.value = this.value.replace(/[^0-9.]/g, '');">
							~
							To
							<!-- <v-text-field
								v-model="filterToScore"
								label=""
								persistent-hint
							></v-text-field> -->
							<input
								v-model="filterToScore"
								type="text"
								maxlength="10"
								placeholder=""
								oninput="javascript: this.value = this.value.replace(/[^0-9.]/g, '');">

							<br />
							<button @click.stop="resetFilterData('values')">초기화</button>
							<button @click.stop="runFilter('values')">실행</button>
						</v-tab-item>
						<v-tab-item
							:key="'numericTab'">
							<v-select
								v-model="numFilterSelected"
								:items="numFilterOptions"
								label=""
							></v-select>

							<v-autocomplete
								v-model="filterNumbericScore"
								:items="ficcScoreFilterList"
								label="Select a value"
								chips
								color="blue"
							>
							</v-autocomplete>

							<button @click.stop="resetFilterData('numberic')">초기화</button>
							<button @click.stop="runFilter('numberic')">실행</button>
						</v-tab-item>
					</v-tabs-items>
				</slot>
			</div>
		</div>
	</div>
</template>

<script>
import { constant, getDateAndTime } from '../mixin/index'
import { mapGetters } from 'vuex'

export default {
	name: 'ScoreFilterPop',

    components: {

    },

    data() {
        return {
			activeTab: 'valuesTab',

			//filterNumbericScore: '',

			scoreFilterData: {
				filterType: '',
				filterFromScore: '',
				filterToScore: '',
				numFilterSelected: '',
				filterNumbericScore: '',
			},
        };
    },

    mixins: [constant, getDateAndTime],

    computed: {
		...mapGetters('ficcStore', [
			'ficcDateFilterList',
			'ficcScoreFilterList',
			'ficcDateNumFilterList',
		]),

        filterFromScore: {
            get() {
                return this.scoreFilterData.filterFromScore
            },
            set (value) {
				this.scoreFilterData.filterFromScore = value
            }
        },
        filterToScore: {
            get() {
                return this.scoreFilterData.filterToScore
            },
            set (value) {
				this.scoreFilterData.filterToScore = value
            }
        },
        numFilterSelected: {
            get() {
                return this.scoreFilterData.numFilterSelected
            },
            set (value) {
				this.scoreFilterData.numFilterSelected = value
            }
        },
        filterNumbericScore: {
            get() {
                return this.scoreFilterData.filterNumbericScore
            },
            set (value) {
				this.scoreFilterData.filterNumbericScore = value
            }
        },
	},

	props: {
		visibleSF: {
			type: Boolean,
			require: true,
			default: false
		},
		title: {
			type: String,
			require: false,
		},
	},

	created() {

    },

	mounted() {

    },

	methods: {
		handleWrapperClick() {
			this.$emit('update:visibleSF', false)
		},

		initData() {
			let lfrScore = this.scoreFilterData.filterFromScore
			let ltoScore = this.scoreFilterData.filterToScore
			console.log('>>>>> lfrScore ::: ', lfrScore)
			console.log('>>>>> ltoScore ::: ', ltoScore)

			if(lfrScore == '' && ltoScore == '') {
				this.scoreFilterData.filterFromScore = this.ficcScoreFilterList[0]
				this.scoreFilterData.filterToScore = this.ficcScoreFilterList[this.ficcScoreFilterList.length - 1];
				console.log('>>>>> this.scoreFilterData.filterFromScore ::: IIIII ::: ', this.scoreFilterData.filterFromScore)
				console.log('>>>>> this.scoreFilterData.filterToScore ::: IIIII ::: ', this.scoreFilterData.filterToScore)
			}

			let lnumFilterSelected = this.scoreFilterData.numFilterSelected
			console.log('>>>>> lnumFilterSelected ::: ', lnumFilterSelected)
			if(lnumFilterSelected == '' || lnumFilterSelected == null) {
				this.scoreFilterData.numFilterSelected = '<'
			}
		},

        runFilter(filterType) {
			// Values Filter인 경우
			if(filterType == 'values') {
				let lfrScore = this.filterFromScore
				if(lfrScore == null || lfrScore == '') {
					alert("Score를 입력해주세요.")
					return;
				}

				let ltoScore = this.filterToScore
				if(ltoScore == null || ltoScore == '') {
					alert("Score를 입력해주세요.")
					return;
				}
			}

			// Numberic Filter인 경우는 선택한 값 체크하기
			if(filterType == 'numberic') {
				console.log('>>>>> this.filterNumbericScore ::: ', this.filterNumbericScore)
				if(this.filterNumbericScore == null || this.filterNumbericScore == '' || this.filterNumbericScore == 'undefined') {
					alert("Score를 선택해주세요.")
					return;
				}
			}

			console.log('>>>>> runFilter >>>>> this.scoreFilterData ::: ', this.scoreFilterData)
			console.log('>>>>> runFilter >>>>> this.numFilterSelected ::: ', this.numFilterSelected)

			this.scoreFilterData.filterType = filterType

			this.scoreFilterData.numFilterSelected = this.numFilterSelected
			this.scoreFilterData.filterNumbericScore = this.filterNumbericScore


            const currentFilterData = this.scoreFilterData
			console.log('>>>>> currentFilterData ::: ', currentFilterData)

            this.$emit('_run-scorefilter', currentFilterData)

			this.handleWrapperClick()
        },

		resetFilterData(filterType) {
			// Values Filter인 경우
			//if(filterType == 'values') {
				this.scoreFilterData.filterType = ''
				this.scoreFilterData.filterFromScore = ''
				this.scoreFilterData.filterToScore = ''
				this.scoreFilterData.numFilterSelected = '<'
				this.scoreFilterData.filterNumbericScore = null
				console.log('>>>>> resetFilterData ::: this.scoreFilterData ::: ', this.scoreFilterData)

				this.scoreFilterData.filterFromScore = this.ficcScoreFilterList[0]
				this.scoreFilterData.filterToScore = this.ficcScoreFilterList[this.ficcScoreFilterList.length - 1];
			//}

			// Numberic Filter인 경우
			// if(filterType == 'numberic') {

			// }

			// 메인화면 데이타 
			this.$emit('_reset-scorefilter')
		},
	},
}
</script>

<style lang="scss">
$module: 'my-modal';
.#{$module} {
	// This is modal bg
	background-color: rgba(0,0,0,.7);
	top: 0; right: 0; bottom: 0; left: 0;
	position: fixed;
	overflow: auto;
	margin: 0;
	//This is modal layer
	&__dialog{
		left: 70%;
		top: 175px;
		width: 500px;
		position: absolute;
		background: #fff;
		margin-bottom: 50px;
	}
	&__header {
		font-size: 28px;
		font-weight: bold;
		line-height: 1.29;
		padding: 16px 16px 0 25px;
		position: relative;
	}
	&__body {
		padding: 25px;
		min-height: 150px;
		max-height: 412px;
		overflow-y: scroll;
	}
}
</style>