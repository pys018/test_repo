import '@babel/polyfill'
import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import MultiFiltersPlugin from './plugins/MultiFilters'
import router from './routes/index.js'
import store from './store/index.js';
import axios from 'axios'
import VueAxios from 'vue-axios'
import VueMask from 'v-mask'
import highcharts from "highcharts-vue";

Vue.use(VueAxios, axios)
Vue.use(VueMask)
Vue.use(highcharts);

Vue.config.productionTip = false

Vue.use(MultiFiltersPlugin)

new Vue({
    vuetify,
    router,
    store,
    render: h => h(App)
}).$mount('#app')