import Highcharts from "highcharts-vue";

export default {
    data: () => ({
        chartInstance: null,
        isChartInitialized: false
    }),
    computed: {
        chartOption: function() {
            return {}
        }
    },
    watch: {
        chartOption: function() {
            this.isChartInitialized && this.plot()
        }
    },
    mounted() {
        this.plot()
        this.isChartInitialized = true
    },
    methods: {
        plot: function() {
            if (this.chartInstance === null) {
                //this.chartInstance = Highcharts.init(this.$refs.chart)
            }

            this.chartInstance.setOption(this.chartOption, true)
        }
    }
}