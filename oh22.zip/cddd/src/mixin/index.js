import {
    offsetSelected,
    offsetOptions,
    refreshSelected,
    refreshOptions,
    xaxisUnitSelected,
    xaxisUnitOptions,
    dateScoreHeaders,
    numFilterSelected,
    numFilterOptions,
    filterEditorDatePrefix,
    filterEditorScorePrefix,
    filterEditorMiddle,
    caseResultHeaders,
    ficcYaxisPriceSelected,
    equityYaxisPriceSelected,
    yaxisPriceOptions,
} from '../assets/constant'

export const constant = {
    created: function() {
        this.offsetSelected = offsetSelected
        this.offsetOptions = offsetOptions
        this.refreshSelected = refreshSelected
        this.refreshOptions = refreshOptions
        this.xaxisUnitSelected = xaxisUnitSelected
        this.xaxisUnitOptions = xaxisUnitOptions
        this.dateScoreHeaders = dateScoreHeaders
        this.numFilterSelected = numFilterSelected
        this.numFilterOptions = numFilterOptions
        this.filterEditorDatePrefix = filterEditorDatePrefix
        this.filterEditorScorePrefix = filterEditorScorePrefix
        this.filterEditorMiddle = filterEditorMiddle
        this.caseResultHeaders = caseResultHeaders
        this.ficcYaxisPriceSelected = ficcYaxisPriceSelected
        this.equityYaxisPriceSelected = equityYaxisPriceSelected
        this.yaxisPriceOptions = yaxisPriceOptions
    },
}

export const getDateAndTime = {
    methods: {
        getDateAndTime() {
            let offset = new Date().getTimezoneOffset() * 60000;
            let today = new Date(Date.now() - offset);
            today = today.toISOString();
            return today
        }
    }
}