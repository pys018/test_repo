import Vue from 'vue'
import VueRouter from 'vue-router'

import ficc from '../views/FICC.vue'
import page2 from '../views/page2.vue'
import page3 from '../views/page3.vue'

import testpage from '../test/testpage.vue'

import ChartSample from '../test/ChartSample.vue'

// import ServerSideSearch from '../test/ServerSideSearch.vue'
// import MultipleFiltersTable from '../components/MultipleFiltersTable.vue'

Vue.use(VueRouter)

const router = new VueRouter({
    mode: 'history',
    routes: [{
            path: '/ficc',
            component: ficc
        },
        {
            path: '/page2',
            component: page2
        },
        {
            path: '/page3',
            component: page3
        },
        {
            path: '/testpage',
            component: testpage
        },
        {
            path: '/ChartSample',
            component: ChartSample
        },
        // {
        //     path: '/sss',
        //     component: ServerSideSearch
        // },
        // {
        //     path: '/mft',
        //     component: MultipleFiltersTable
        // },
    ]
})

export default router;