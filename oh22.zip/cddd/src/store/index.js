import Vue from 'vue';
import Vuex from 'vuex';

import ficcStore from './modules/ficcStore';

Vue.use(Vuex);

const store = new Vuex.Store({
    modules: {
        ficcStore
    }
})

export default store;