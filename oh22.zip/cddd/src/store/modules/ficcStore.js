import {
    FICC_SET_ASSET_LIST,
    FICC_SET_DATE_SCORE_LIST,
    FICC_SET_CASE_RESULT_LIST,
    FICC_SET_CASE_RESULT_LIST_TEST,
    FICC_SET_CASE_RESULT_LIST_TEST2
} from '../mutation-types'

// import {
// 	offsetSelected,
// 	offsetOptions,
// 	refreshSelected,
// 	refreshOptions,
// 	xaxisUnitSelected,
// 	xaxisUnitOptions,
// 	dateScoreHeaders,
// 	numFilterSelected,
// 	numFilterOptions,
// 	filterEditorDatePrefix,
// 	filterEditorScorePrefix,
// 	filterEditorMiddle,
// 	caseResultHeaders,
// 	ficcYaxisPriceSelected,
// 	equityYaxisPriceSelected,
// 	yaxisPriceOptions,
// } from '../../assets/constant'

import {
    fetchAssetList,
    fetchDateScoreList,
    fetchCaseResultList,
    fetchCaseResultListTEST,
    fetchCaseResultListTEST2
} from '../../api/index'

import {
    ficcAssetOptionsData,
    ficcDateScoreListData,
    ficcCaseResultListData,
    ficcCaseResultListDataTest,
    ficcCaseResultListDataTest2
} from '../../assets/data'

const state = () => ({
    ficcAssetOptions: [],
    ficcDateScoreList: [],
    orgficcDateScoreList: [],
    ficcCaseResultList: []
})

const getters = {
    ficcDateFilterList: state => {
        let _DATE = []
        state.ficcDateScoreList.map((date) => {
            //_DATE.push(date.dateVal.substr(2, 6))
            _DATE.push(date.dateVal)
        })
        return _DATE.sort()
    },
    ficcScoreFilterList: state => {
        let _SCORE = []
        state.ficcDateScoreList.map((score) => {
            _SCORE.push(score.scoreVal)
        })
        return _SCORE.sort(function(a, b) { return a - b; });
    },
    ficcDateNumFilterList: state => {
        let _DATE = []
        state.ficcDateScoreList.map((date) => {
            _DATE.push(date.dateVal)
        })
        return _DATE.sort()
    },
}

const mutations = {
    [FICC_SET_ASSET_LIST](state, { ficcAssetOptionsData }) {
        state.ficcAssetOptions = ficcAssetOptionsData
    },

    [FICC_SET_DATE_SCORE_LIST](state, { ficcDateScoreListData }) {
        state.ficcDateScoreList = ficcDateScoreListData,
            state.orgficcDateScoreList = ficcDateScoreListData
    },

    [FICC_SET_CASE_RESULT_LIST](state, { ficcCaseResultListData }) {
        state.ficcCaseResultList = ficcCaseResultListData
    },

    [FICC_SET_CASE_RESULT_LIST_TEST](state, { ficcCaseResultListDataTest }) {
        state.ficcCaseResultList = ficcCaseResultListDataTest
    },
    [FICC_SET_CASE_RESULT_LIST_TEST2](state, { ficcCaseResultListDataTest2 }) {
        state.ficcCaseResultList = ficcCaseResultListDataTest2
    },
}

const actions = {
    async ficcFetchAssetList({ commit }, { reqParam }) {
        // console.log("=====>>>>> ficcStore.js >>>>> actions >>> ASSET 리스트 불러오기    START <<<<<=====")
        // console.log('=====>>>>> reqParam', reqParam)
        return fetchAssetList(reqParam).then(res => {
            // console.log(">>>>> ASSET 리스트 불러오기 완료 !!!" + JSON.stringify(res))
            commit({ type: FICC_SET_ASSET_LIST, ficcAssetOptionsData })
        });
    },

    async ficcFetchDateScoreList({ commit }, { reqParam }) {
        // console.log("=====>>>>> ficcStore.js >>>>> actions >>> DATE / SCORE 리스트 불러오기    START <<<<<=====")
        // console.log('=====>>>>> reqParam', reqParam)
        return fetchDateScoreList(reqParam).then(res => {
            // console.log(">>>>> DATE / SCORE 리스트 불러오기 완료 !!!" + JSON.stringify(res))
            commit({ type: FICC_SET_DATE_SCORE_LIST, ficcDateScoreListData })
        });
    },

    async ficcFetchCaseResultList({ commit }, { reqParam }) {
        // console.log("=====>>>>> ficcStore.js >>>>> actions >>> CASE Result 불러오기    START <<<<<=====")
        // console.log('=====>>>>> reqParam', reqParam)
        return fetchCaseResultList(reqParam).then(res => {
            // console.log(">>>>> CASE Result 불러오기 완료 !!!" + JSON.stringify(res))
            commit({ type: FICC_SET_CASE_RESULT_LIST, ficcCaseResultListData })
        });
    },

    async ficcFetchCaseResultListTEST({ commit }, { reqParam }) {
        console.log("=====>>>>> ficcStore.js >>>>> actions >>> CASE Result 불러오기    TEST    START <<<<<=====")
        return fetchCaseResultListTEST(reqParam).then(res => {
            commit({ type: FICC_SET_CASE_RESULT_LIST_TEST, ficcCaseResultListDataTest })
        });
    },
    async ficcFetchCaseResultListTEST2({ commit }, { reqParam }) {
        console.log("=====>>>>> ficcStore.js >>>>> actions >>> CASE Result 불러오기    TEST    START <<<<<=====")
        return fetchCaseResultListTEST2(reqParam).then(res => {
            commit({ type: FICC_SET_CASE_RESULT_LIST_TEST2, ficcCaseResultListDataTest2 })
        });
    },
}

export default {
    namespaced: true,
    state,
    getters,
    mutations,
    actions,
}