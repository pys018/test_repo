<template>
	<div id="app">
		<div id="chart"></div>
	</div>
</template>

<script>
// https://blog.naver.com/opgj123/221503164752

import Highcharts from 'highcharts'

export default {
	name: 'App',

	// components: {
	// 	Highcharts
	// },

	data() {
		return {
			dateData : '',
			lineData : '',
			highchartsOptions : ''
		}
	},

	// created 를 통해 data를 가져옵니다.
	created() {
		this.getLineData();
	},

	// mounted 를 통해 돔이 로드가 된 이후에 차트를 그려줍니다.
	mounted() {
		// drawChar() 의 리턴값인 객체를 highchartsOptions 값에 대입을 한 이후에
		this.highchartsOptions = this.drawChart();

		// highchartsOptions 를 이용하여 chart를 그려줍니다.
		Highcharts.chart(this.highchartsOptions);
	},

	methods: {
		getLineData() {
			this.dateData = ["2019-04-01", "2019-03-31", "2019-03-30", "2019-03-29", "2019-03-28", "2019-03-27", "2019-03-26"];
			this.lineData = [
				{
					name : "League of Legend",
					data : [3000, 2000, 1000, 5000, 6000, 7000, 8000]
				},
				{
					name : "Battleground",
					data : [8000, 5000, 3000, 7000, 7000, 8000, 9000]
				},
				{
					name : "FIFA Online4",
					data : [10000, 9000, 8000, 7000, 9000, 3000, 6000]
				}
			]

			// this.dateData = ''
			// this.lineData = ''
		},
		// drawChart는 chart를 그려주기 위한 설정입니다.
		drawChart() {
			var chart = {
				chart : {
					renderTo : 'chart'
				},
				title : {
					text : 'line-chart example'
				},
				subtitle : {
					text : '2019-04-01'
				},
				xAxis : {
					categories : this.dateData
				},
				credits : {
					enabled : false
				},
				legend : {
					layout : 'vertical',
					align : 'right',
					verticalAlign : 'middle'
				},
				series : this.lineData
			}
			return chart;
		}
	}
}
</script>