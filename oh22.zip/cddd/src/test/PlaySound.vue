<template>
	<div>
		<div class="heading">
			<h1>Play Sound</h1>
			<h4>Playing audio files with Vue.js</h4>
		</div>

		<div class="container" id="app">
			<div class="form-group">
				<label>
					<button class="btn btn-primary btn-sm"
						@click.prevent="playSound('http://soundbible.com/mp3/Air Plane Ding-SoundBible.com-496729130.mp3')">
						<span class="fa fa-play-circle-o"></span>
					</button>
					Play Air Plane Ding
				</label>
				<br/>
				<label>
					<button class="btn btn-primary btn-sm"
						@click.prevent="playSound('http://soundbible.com/mp3/Elevator Ding-SoundBible.com-685385892.mp3')">
						<span class="fa fa-play-circle-o"></span>
					</button>
					Play Elevator Ding
				</label>
			</div>
		</div>
	</div>
</template>

<script>
new Vue({
	el: '#app',
	data: {
		text: ''
	},
	methods: {
		playSound(sound) {
			if(sound) {
				var audio = new Audio(sound);
				audio.play();
			}
		}
	}
});
</script>

<style>
$purple: #5c4084;

body {
	background-color: $purple;
	padding: 50px;
}
.container {
	padding: 40px 80px 15px 80px;
	background-color: #fff;
	border-radius: 8px;
	max-width: 400px;
}
.heading {
	text-align: center;
	h1 {
		background: -webkit-linear-gradient(#fff, #999);
		-webkit-text-fill-color: transparent;
		-webkit-background-clip: text;
		text-align: center;
		margin: 0 0 5px 0;
		font-weight: 900;
		font-size: 4rem;
		color: #fff;
	},
	h4 {
		color: lighten(#5c3d86,30%);
		text-align: center;
		margin: 0 0 35px 0;
		font-weight: 400;
		font-size: 24px;
	}
}
.btn{
	outline: none !important;
}
.btn.btn-primary {
	background-color: $purple;
	border-color: $purple;
	outline: none;
	&:hover {
		background-color: darken($purple, 10%);
		border-color: darken($purple, 10%);
	}
	&:active, &:focus {
		background-color: lighten($purple, 5%);
		border-color: lighten($purple, 5%);
	}
	& .fa {
		padding-right: 4px;
	}
}
.btn-sm {
	font-size: 22px;
	padding: 2px 1px 2px 4px;
	line-height: 12px;
	margin-right: 10px;
}
.form-group {
	margin-bottom: 25px;
}

</style>