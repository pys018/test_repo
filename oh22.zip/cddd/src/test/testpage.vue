<template>
	<div id="app">

		<div>{{dict}}</div>

		<v-app id="inspire">
			<v-card>
				<v-card-text>
					<v-layout wrap>
						<v-flex xs3 md3>
							<v-autocomplete
								v-model="product"
								:items="products"
								label=""
								chips
								color="blue"
							>
							</v-autocomplete>
						</v-flex>
					</v-layout>
				</v-card-text>
			</v-card>
		</v-app>
	</div>
</template>

<script>
import axios from 'axios';

// import inputDatas from "../assets/jsondata/INPUT_DATA_SAMPLE.json";
import inputDatas from "../assets/jsondata/PROC_RESULT.json";

import { ficcDateScoreListData } from '../assets/data'

export default {
	name: 'testpage',

	// data () {
	data: () => ({
		model: null,
		product: null,
		category: null,
		purpose: null,
		products: [
			'Samson', 'Wichita', 'Combustion', 'Triton',
			'Helios', 'Wimbeldon', 'Brixton', 'Iguana',
			'Xeon', 'Falsy', 'Armagedon', 'Zepellin'
		],


		// inputDatas: inputDatas
		items:null,


		jsonTestData: "{'id':'11111', 'name':'test'}",
	}),

	computed: {
		categories() {
			return Object.keys(this.categoriesPurposes)
		},
		purposes() {
			if (!this.category) {
				return null
			} else {
				return this.categoriesPurposes[this.category]
			}
		},

		dict() {
			return JSON.parse(JSON.stringify(this.jsonTestData))
		}
	},

	methods: {
		generateUUID: function () {
			var d = new Date().getTime();
			var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = (d + Math.random()*16)%16 | 0;
				d = Math.floor(d/16);
				return (c=='x' ? r : (r&0x7|0x8)).toString(16);
			});

			return uuid;
		},

		getMillisecondes: function () {
			var today = new Date();
			var ms = today.getMilliseconds();
			console.log(">>>>> today :::", today);
			console.log(">>>>> ms :::", ms);

			return ms;
		},
	},

	mounted() {
		console.log("-------------- mounted    START ----------");
		var uuid = this.generateUUID();
		console.log(">>>>> uuid :::", uuid);


		var ms = this.getMillisecondes();
		console.log(">>>>> ms :::", ms);


		//기존 JSON obj를 String으로 만들었습니다.
		var obj = '{ "NAME" : "Garry", "AGE" : 25, "jobTitle" : "Front End Technical Lead", "JOB" : "Photographer" }';
		console.log("-------------- obj result ----------");
		console.log(obj);

		//JSON obj로 만들기
		var jsonObj = JSON.parse(obj);
		console.log("--------------JSON.parse(obj) result ----------");
		console.log(jsonObj);

		//다시 String으로 만들기
		var jsonStr = JSON.stringify(jsonObj);
		console.log("--------------JSON.stringify(jsonObj) result ----------");
		console.log(jsonStr);



		var obj2 = { "peoples" : [
									{ "NAME" : "Garry", "AGE" : 25, "jobTitle" : "Front End Technical Lead", "JOB" : "Photographer" },
									{ "NAME" : "Merry", "AGE" : 30, "jobTitle" : "Developer", "JOB" : "Developer" },
									{ "NAME" : "Heather", "AGE" : 25, "jobTitle" : "Designer", "JOB" : "Designer" }
								]
				};
		console.log("--------------obj2 result ----------");
		console.log(obj2);
		console.log("--------------obj2.peoples[0].NAME result ----------");
		console.log(obj2.peoples[0].NAME);
		// console.log("--------------each result ----------");
		// $(obj2.peoples).each(function(index, people){
		// 	console.log(index + " ::: " , people.NAME);
		// });



		//JSON 객체 생성 방법
		var personInfo = {
			name : "Garry",
			age : 20,
			jobInfo : {
				jobname : 'programmer',
				jobAddress : 'seoul',
				phoneNum : '0101234232315'
			}
		};

		//배열로 생성 방법
		var hobbyList = new Array();
		var a = {hobby : "programming"};
		var b = {hobby : "baking" , hobby2 : "tiyping", hobby3 : "searching"};
		var c = {hobby : "posting"};

		hobbyList.push(a);
		hobbyList.push(b);
		hobbyList.push(c);

		//personInfo Object에 hobbyList라는 이름으로 hobbyList를 추가시킨다는 의미.
		personInfo.hobbyList = hobbyList;
		// console.log("personInfo >>> ", personInfo);
		// console.log("personInfo >>> ", JSON.parse(personInfo));		// 에러발생
		console.log("personInfo >>> ", JSON.parse(JSON.stringify(personInfo)));
		console.log("\n\n\n\n\n");




		var strINPUT1_SCREEN = '';
		var strINPUT1_ASSETCATEGORY = '';
		var strINPUT1_SRCHDATE = '';
		var strINPUT1_SRCHTIME = '';
		var strINPUT1_ASSET = '';
		var strINPUT1_OFFSET = '';
		var strINPUT1_TIMEUNIT = '';

		inputDatas.INPUT1.map((datas) => {
			strINPUT1_SCREEN = datas.SCREEN;
			strINPUT1_ASSETCATEGORY = datas.ASSETCATEGORY;
			strINPUT1_SRCHDATE = datas.SRCHDATE;
			strINPUT1_SRCHTIME = datas.SRCHTIME;
			strINPUT1_ASSET = datas.ASSET;
			strINPUT1_OFFSET = datas.OFFSET;
			strINPUT1_TIMEUNIT = datas.TIMEUNIT;
		});

		var jsonINPUT1 = {
			"INPUT1": {
				"SCREEN": strINPUT1_SCREEN,
				"ASSETCATEGORY": strINPUT1_ASSETCATEGORY,
				"SRCHDATE": strINPUT1_SRCHDATE,
				"SRCHTIME": strINPUT1_SRCHTIME,
				"ASSET": strINPUT1_ASSET,
				"OFFSET": strINPUT1_OFFSET,
				"TIMEUNIT": strINPUT1_TIMEUNIT,
			}
		};
		console.log(">>>>> jsonINPUT1 ::: ", JSON.parse(JSON.stringify(jsonINPUT1)));



		var INPUT2_DATE = [];
		var INPUT2_SCORE = [];
		var strINPUT2_DATE = '';
		var strINPUT2_SCORE = '';
		inputDatas.INPUT2.map((datas) => {
			// INPUT2_DATE.push(datas.DATE.replace(/"/g, ""));
			// INPUT2_SCORE.push(datas.DATE.replace(/["]+/g, ''));
			// INPUT2_SCORE.push(datas.SCORE.replace(/"/g, ""));
			// INPUT2_SCORE.push(datas.SCORE.replace(/["]+/g, ''));

			// strINPUT2_DATE += datas.DATE + ',';
			// strINPUT2_SCORE += datas.SCORE + ',';
			strINPUT2_DATE = datas.DATE;
			strINPUT2_SCORE = datas.SCORE;
		});
		// strINPUT2_DATE = strINPUT2_DATE.substr(0, strINPUT2_DATE.length -1);
		//strINPUT2_DATE = '[' + strINPUT2_DATE + ']';
		// strINPUT2_SCORE = strINPUT2_SCORE.substr(0, strINPUT2_SCORE.length -1);
		//strINPUT2_SCORE = '[' + strINPUT2_SCORE + ']';
		console.log(">>>>> strINPUT2_DATE ::: ", strINPUT2_DATE);
		console.log(">>>>> strINPUT2_SCORE ::: ", strINPUT2_SCORE);

		INPUT2_DATE.push(strINPUT2_DATE);
		INPUT2_SCORE.push(strINPUT2_SCORE);
		// console.log(">>>>> INPUT2_DATE ::: ", INPUT2_DATE);
		// console.log(">>>>> INPUT2_SCORE ::: ", INPUT2_SCORE);

		var jsonINPUT2 = {
			"INPUT2": {
				// "DATE": strINPUT2_DATE,
				// "SCORE": strINPUT2_SCORE,
				"DATE": INPUT2_DATE,
				"SCORE": INPUT2_SCORE,
			}
		};
		console.log(">>>>> jsonINPUT2 ::: ", JSON.parse(JSON.stringify(jsonINPUT2)));
		//console.log(">>>>> jsonINPUT2 ::: ", JSON.parse(jsonINPUT2));





		/*
		const STD_DATE = [];
		const REF_DATE = [];
		inputDatas.INPUT3.map((datas) => {
			//console.log(">>>>> datas ::: ", datas);
			STD_DATE.push(datas.STD_DATE);
			REF_DATE.push(datas.REF_DATE);
		});

		let uniqueSTD_DATE = [];
		STD_DATE.forEach((element) => {
			if(!uniqueSTD_DATE.includes(element)) {
				uniqueSTD_DATE.push(element);
			}
		});
		console.log(">>>>> uniqueSTD_DATE ::: ", uniqueSTD_DATE);

		let uniqueREF_DATE = [];
		REF_DATE.forEach((element) => {
			if(!uniqueREF_DATE.includes(element)) {
				uniqueREF_DATE.push(element);
			}
		});
		console.log(">>>>> uniqueREF_DATE ::: ", uniqueREF_DATE);
		console.log("");
		console.log("");



		var allINPUT3 = [];
		allINPUT3 = allINPUT3.push(inputDatas.INPUT3);

		var sSTD_DATE = "";
		var sREF_DATE = "";

		const REF_TIME = [];
		const CLOSE_PRICE = [];

		var jsonINPUT3 = {
			"INPUT3": {
				"DATAS": [
					{
						"STD_DATE": strINPUT2_DATE,
						"REF_DATE": strINPUT2_DATE,
						"REF_TIME": strINPUT2_DATE,
						"CLOSE_PRICE": strINPUT2_SCORE
					}
				]
			}
		};
		console.log(">>>>> jsonINPUT3 ::: ", JSON.parse(JSON.stringify(jsonINPUT3)));

		for(var i = 0; i < uniqueSTD_DATE.length; i++) {
			sSTD_DATE = uniqueSTD_DATE[i];
			console.log(">>>>> sSTD_DATE ::: ", sSTD_DATE);

			for(var j = 0; j < uniqueREF_DATE.length; j++) {
				sREF_DATE = uniqueREF_DATE[j];
				console.log(">>>>> sREF_DATE ::: ", sREF_DATE);

				inputDatas.INPUT3.map((datas) => {
					if(sSTD_DATE == datas.STD_DATE && sREF_DATE == datas.REF_DATE) {
						REF_TIME.push(datas.REF_TIME);
						CLOSE_PRICE.push(datas.CLOSE_PRICE);
						console.log(">>>>> CLOSE_PRICE ::: ", CLOSE_PRICE);
					}
				});

				continue;

				// var newArr = allINPUT3.filter(function(item) {
				// 	return item.STD_DATE === sSTD_DATE && item.REF_DATE === sREF_DATE;
				// });
				// console.log(">>>>> CLOSE_PRICE ::: ", CLOSE_PRICE);


				//inputDatas.INPUT3.findIndex(x => x.value === 'something');
			}
		}
		*/


		var jsonINPUT3 = {
			"INPUT3": {}
		};

		//배열로 생성 방법
		var idx3 = 0;
		var INPUT3_DATAS = new Array();

		// var INPUT3_DATAS = [];
		// var INPUT3_REF_TIME = [];
		// var INPUT3_CLOSE_PRICE = [];

		var strINPUT3_STD_DATE = '';
		var strINPUT3_REF_DATE = '';
		var strINPUT3_REF_TIME = '';
		var strINPUT3_CLOSE_PRICE = '';
		inputDatas.INPUT3.map((datas) => {
			strINPUT3_STD_DATE = datas.STD_DATE;
			strINPUT3_REF_DATE = datas.REF_DATE;
			strINPUT3_REF_TIME = datas.REF_TIME;
			strINPUT3_CLOSE_PRICE = datas.CLOSE_PRICE;
			// console.log(">>>>> strINPUT3_STD_DATE ::: ", strINPUT3_STD_DATE);
			// console.log(">>>>> strINPUT3_REF_DATE ::: ", strINPUT3_REF_DATE);
			// console.log(">>>>> strINPUT3_REF_TIME ::: ", strINPUT3_REF_TIME);
			// console.log(">>>>> strINPUT3_CLOSE_PRICE ::: ", strINPUT3_CLOSE_PRICE);

			var INPUT3_REF_TIME = [];
			var INPUT3_CLOSE_PRICE = [];
			INPUT3_REF_TIME.push(strINPUT3_REF_TIME);
			INPUT3_CLOSE_PRICE.push(strINPUT3_CLOSE_PRICE);

			// INPUT3_DATAS.push({"STD_DATE": strINPUT3_STD_DATE, "REF_DATE": strINPUT3_REF_DATE, "REF_TIME": INPUT3_REF_TIME, "CLOSE_PRICE": INPUT3_CLOSE_PRICE});
			// jsonINPUT3.INPUT3.DATAS = INPUT3_DATAS;



			idx3 = {"STD_DATE": strINPUT3_STD_DATE, "REF_DATE": strINPUT3_REF_DATE, "REF_TIME": INPUT3_REF_TIME, "CLOSE_PRICE": INPUT3_CLOSE_PRICE};
			INPUT3_DATAS.push(idx3);

			jsonINPUT3.INPUT3.DATAS = INPUT3_DATAS;

			idx3++;
		});

		console.log(">>>>> jsonINPUT3 ::: ", JSON.parse(JSON.stringify(jsonINPUT3)));
		// console.log(">>>>> jsonINPUT3 ::: ", JSON.parse(jsonINPUT3));





		// https://www.python2.net/questions-326723.htm
		var dates = function(startDate, endDate) {
			var dates = [],
				currentDate = startDate,

			addDays = function(days) {
				var date = new Date(this.valueOf());
				date.setDate(date.getDate() + days);
				return date;
			};

			while(currentDate <= endDate) {
				dates.push(currentDate);
				currentDate = addDays.call(currentDate, 1);
			}

			return dates;
		};
		var startDate = new Date("2019-04-01");
		var endDate = new Date("2019-04-25");
		var resultdates = dates(startDate, endDate);
		// console.log('>>>>> resultdates ::: ', resultdates);

		// var holidays = [new Date("2019-04-19"), new Date("2019-04-22")];
		// var workingDays = dates.filter(function(e, index) {
		// 	return (e.getDay() != 0 && e.getDay() != 6 && !holidays.some(d => +d === +e));
		// });
		// console.log('>>>>> workingDays ::: ', workingDays);

		// var holidays = [new Date("2019-04-19"), new Date("2019-04-22")];
		// var workingDays = dates.filter(function(e, index) {
		// 	return (e.getDay() != 0 && e.getDay() != 6 && !holidays.some(x=>+x===+e));
		// });
		// console.log('>>>>> workingDays ::: ', workingDays);





		// https://niceman.tistory.com/77
		let data= [
			{name: "jack", age: 20}, 
			{name: "kevin", age: 16}, 
			{name: "rick", age: 27}, 
			{name: "marry", age: 21}, 
			{name: "rilly", age: 19}
		]
		// age가 20이상인 원소 추출(필터링)
		let result = data.filter( x => { 
			return x.age >= 20
		});
		//결과 출력
		console.log(result);

		// x : 요소, idx : 인덱스, array : 원 배열
		let result2 = data.filter( (x, idx, array) => { 
			return idx === 0 && x.age >= 20
		});
		//결과 출력
		console.log(result2);

		// x : 요소, idx : 인덱스, array : 원 배열
		let result3 = ficcDateScoreListData.filter( (x, idx, array) => { 
			return x.dateVal >= '20150703' && x.dateVal <= '20170711'
		});
		//결과 출력
		console.log(result3);





		// https://ko.ojit.com/so/javascript/47736
		var test = {
			"id": "109",
			"No. of interfaces": "411111111111"
		}
		//결과 출력
		console.log('>>>>> result ::: ', test["No. of interfaces"]);




		// https://velog.io/@adbr/JSON.stringify-%EC%9D%B4%EB%9E%80
		// 함수일 땐 함수를 거쳐 변환(replace function)후 json 문자열에 적용
		function customReplacer(key, value) {
			if(typeof value === "string") {
				return value.toUpperCase();
			}
			return value;
		}

		var objr = {name: "bora", nickname: "dabo", age: 20};
		var returnVal = JSON.stringify(objr, customReplacer); 

		console.log(returnVal); // {"name":"BORA","nickname":"DABO","age":20}
	},
};
</script>

<style>

</style>