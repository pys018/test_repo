<template>
	<div id="app">
		<form class="s-form">
			<select v-model="option" class="form-group" v-on:change="filter">
				<option value="all">All</option>
				<option v-for="c in categories" v-bind:value="c" v-bind:key="c.id">{{ c }}</option>
			</select>
			<input v-model="search" v-on:keyup="filter" type="text" placeholder="search..." class="form-group">
		</form>
		<div class="content">
			<div class="button-group">
				<div class="buttons">
					<span>view</span>
					<button v-for="b in buttons.view" v-bind:title="b.title" v-bind:key="b.id"
							v-bind:class="viewType == b.class?'selected':''"
							v-on:click="toggleList('view',b.class)">
						<i class="fas" v-bind:class="'fa-'+b.class"></i>
					</button>
				</div>
				<div class="buttons">
					<span>sort</span>
					<button v-for="b in buttons.sort" v-bind:title="b.title" v-bind:key="b.id"
							v-bind:class="sortType == b.class?'selected':''"
							v-on:click="toggleList('sort',b.class)">
						<i class="fas" v-bind:class="'fa-'+b.class"></i>
					</button>
				</div>
			</div>
			<ul class="todo-list list" v-if="viewType === 'list'">
				<li v-for="(item,index) in todos"  v-bind:key="index"
					v-bind:class="[substring(item.deadline, 0, 8) == getTodayDate? 'deadline':'', item.endDate? 'done':'']"
					v-show="item.filtered!=='y'"
					v-on:click="checkTodo(index)">
					<i class="far" v-bind:class="item.endDate? 'fa-check-square':'fa-square'"></i>
					<span class="title">{{ item.title }}</span>
				<span class="stars">
					<i v-for="n in toNumber(item.important)" class="fas fa-star" v-bind:key="n.id"></i>
				</span>
				</li>
			</ul>
			<ul class="todo-list thumbnail" v-else>
				<li v-for="(item,index) in todos" v-show="item.filtered!=='y'" v-bind:key="index"
					v-bind:class="item.endDate? 'done':''" v-on:click="checkTodo(index)">
					<div class="label">
						<span class="category">{{item.category}}</span>
						<span class="stars">
							<i v-for="n in toNumber(item.important)" class="fas fa-star" v-bind:key="n.id"></i>
						</span>
					</div>
					<img v-bind:src="item.thumbnail">
					<p class="info">
						<span class="title">{{ item.title }}</span>
						<span class="deadline">
							<i class="far" v-bind:class="item.endDate? 'fa-check-square':'fa-square'"></i>
							until {{ formatDate(item.deadline) }}
							<i v-if="substring(item.deadline, 0, 8) == getTodayDate" class="fas fa-bell"></i>
						</span>
					</p>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
import Vue from 'vue'
import axios from 'axios';

export default {
    name: 'todoList',
	data: vm => ({
		option: 'all',
		search: '',
		categories: [],
		todos: [],
		viewType: 'list',
		sortType: 'sort-numeric-up',
		buttons: {
			'view': [
				{'class':'list', 'title':'view in list', selected:true},
				{'class':'th-large', 'title':'view in thumbnail', selected:false}
			],
			'sort': [
				{'class':'sort-numeric-up', 'title':'sort by deadline', selected:true},
				{'class':'sort-alpha-down', 'title':'sort by alphabet', selected:false},
				{'class':'star', 'title':'sort by stars', selected:false}
			]
		}
	}),
	methods: {
		toNumber: function(number){
			if(typeof number == 'string'){
				number = Number(number);
			}
			return number;
		},
		substring : function(str, startIdx, length){
			return str.substr(startIdx, length);
		},
		formatDate: function(str){
			var result = str.substr(0, 4)+'-'+str.substr(4, 2)+'-'+str.substr(6, 2);
			if(result.replace(/-/g, '') == this.getTodayDate){
				result = "today " + str.substr(8, 2)+':'+str.substr(10, 2)+':'+str.substr(12, 2);
			}
			return result;
		},
		checkTodo: function(index){
			var todoObj = this.todos[index];

			if(todoObj.endDate){
				todoObj.endDate = '';
			} else {
				var d = new Date();
				this.todos[index].endDate = this.getTodayDate + d.toTimeString().replace(/[^0-9]/g, '').substr(0, 6);
			}
		}
	},
	computed: {
		getTodayDate: function(){
			var d = new Date();
			var arr = d.toLocaleString().replace(/ /g, '').split('.');
			return arr[0]+(arr[1].length==1?"0"+arr[1]:arr[1])+(arr[2].length==1?"0"+arr[2]:arr[2]);
		}
	},
	created: function() {
		// sendAjax({
		// 	url: '../assets/jsondata/todo.json',
		// 	method:'GET',
		// 	success: function(resp) {
		// 		var respObj = JSON.parse(resp);
		// 		app.categories = respObj.category;
		// 		app.todos = respObj.todos;
		// 	}
		// });

		axios.get(`/assets/jsondata/todo.json`)
				.then(function(response) {
					console.log(response);
					console.log(response.data);
				});

		// axios.get('http://10.17.115.183:8082/api/formal_mp/DAM_FORMAL_MP_S01', {
		// // axios.get('http://localhost:8080/assets/jsondata/todo.json', {
		// 	headers: {
		// 		'Access-Control-Allow-Origin': '*',
		// 		'Content-Type': 'application/json; charset = utf-8',
		// 	},
		// })
		// .then((res, err) => {
		// 	if (err) {
		// 		console.log(err);
		// 	} else {
		// 		console.log(res);
		// 	}
		// });
	}
};
</script>
