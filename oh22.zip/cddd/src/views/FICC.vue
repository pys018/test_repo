<template>
	<v-app>
		<div>
			<v-simple-table >
				<tbody>
					<tr>
						<td width="99%" class="text-center">
							FICC
						</td>
						<td width="1%" class="text-center">
							???
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-simple-table dense border="1">
								<tbody>
									<tr>
										<td></td>
										<td>DATE(로컬)</td>
										<td>
											<v-text-field
												v-mask="'##-##-##'"
												v-model="srchDate"
												label=""
												persistent-hint
												placeholder="YY-MM-DD"
											></v-text-field>
										</td>
										<td></td>
										<td>TIME(로컬)</td>
										<td>
											<v-text-field
												v-mask="'##:##'"
												v-model="srchTime"
												label=""
												persistent-hint
												placeholder="HH:MM"
											></v-text-field>
										</td>
										<td></td>
										<td>ASSET</td>
										<td>
											<v-autocomplete
												v-model="ficcAssetSelected"
												:items="ficcAssetOptions"
												label=""
												chips
												color="blue"
											>
											</v-autocomplete>
										</td>
										<td></td>
										<td>OFFSET</td>
										<td>
											<v-select
												v-model="offsetSelected"
												:items="offsetOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td>
											<v-btn block v-on:click="searchRun">
												실행
											</v-btn>
										</td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td>
											<v-checkbox v-model="realTimeChartChk">
												<template v-slot:label>
													<div>
														RealTime Chart
													</div>
												</template>
											</v-checkbox>
										</td>
										<td></td>
										<td></td>
										<td>
											<v-select
												v-model="refreshSelected"
												:items="refreshOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td>
											<v-select
												v-model="xaxisUnitSelected"
												:items="xaxisUnitOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td>
											<v-select
												v-model="ficcYaxisPriceSelected"
												:items="yaxisPriceOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
								</tbody>
							</v-simple-table>
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-simple-table dense border="1">
								<tbody>
									<tr>
										<td width="79%">

											<ficc-chart ref="ficcchart" v-if="chartData" :chart-data="chartData"></ficc-chart>

										</td>
										<td width="1%"></td>
										<td width="20%">
											<!-- v-if="ficcDateScoreList.length > 0" -->
											<button
												@click="openDateFilter">
												Date Filter
											</button>
											<date-filter-pop
												title=""
												ref="datefilterpop"
												:visibleDF.sync="visibleDF"
												@_run-datefilter="doDateFilter"
												@_reset-datefilter="resetDateFilterData">
											</date-filter-pop>

											<button
												@click="openScoreFilter">
												Score Filter
											</button>
											<score-filter-pop
												title=""
												ref="scorefilterpop"
												:visibleSF.sync="visibleSF"
												@_run-scorefilter="doScoreFilter"
												@_reset-scorefilter="resetScoreFilterData">
											</score-filter-pop>

											<v-data-table
												:headers="dateScoreHeaders"
												:items="ficcDateScoreList"
												class="elevation-1"
												:items-per-page="100"
												hide-default-footer
												@click="clickHeader"
											>
												<template v-slot:header.dateVal >
													<!-- <button @click="console.log('you have clicked me ddddd')">DATE</button> -->
													<button @click="headerClick('date')">DATE</button>
												</template>
												<template v-slot:header.scoreVal >
													<!-- <button @click="console.log('you have clicked me sssss')">Score</button> -->
													<button @click="headerClick('score')">Score</button>
												</template>
											</v-data-table>

											<div class="text-center">
												<v-sheet color="orange lighten-2" class="spacing-playground pa-2">
													<button v-if="dateFiltered == true || scoreFiltered == true" @click="resetAllFilterData">
														[X]
													</button>
													<button v-if="dateFiltered == false && scoreFiltered == false">
														[X]
													</button>

													<button v-if="dateFiltered == true || scoreFiltered == true" @click="openFilterEditor">
														[Filter Editor]
													</button>
													<button v-if="dateFiltered == false && scoreFiltered == false">
														[Filter Editor]
													</button>
													<filter-editor-pop
														title="Filter Editor"
														ref="filtereditorpop"
														:visibleFE.sync="visibleFE"
														:filter-editor-txt="filterEditorTxt"
														@_reset-datefilter="resetDateFilterData"
														@_reset-scorefilter="resetScoreFilterData">
													</filter-editor-pop>
												</v-sheet>
											</div>
										</td>
									</tr>
								</tbody>
							</v-simple-table>
						</td>
					</tr>

					<tr>
						<td>
							▣ CASE FICC Result
						</td>
						<td>
							<v-btn block v-on:click="setCaseResultTest">
								TEST
							</v-btn>
							<v-btn block v-on:click="setCaseResultTest2">
								TEST2
							</v-btn>
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-data-table
								:headers="caseResultHeaders"
								:items="ficcCaseResultList"
								class="elevation-1"
								hide-default-footer
							>
								<template v-slot:item="{ item }">
									<tr>
										<td >{{ item.resultCategoryVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D1HVal)">{{ item.result0D1HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D2HVal)">{{ item.result0D2HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D3HVal)">{{ item.result0D3HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D4HVal)">{{ item.result0D4HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D5HVal)">{{ item.result0D5HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D6HVal)">{{ item.result0D6HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result1D0HVal)">{{ item.result1D0HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result2D0HVal)">{{ item.result2D0HVal }}</td>
									</tr>
								</template>
							</v-data-table>

							<case-result-pop
								title="Case 분석 국면전환"
								ref="caseresultpop"
								:visibleCR.sync="visibleCR"
								:case-result-alert-txt="caseResultAlertTxt">
							</case-result-pop>
						</td>
					</tr>

					<tr>
						<td colspan="2">

						</td>
					</tr>
				</tbody>

			</v-simple-table>
		</div>
	</v-app>
</template>

<script>
import DateFilterPop from '../components/DateFilterPop'
import ScoreFilterPop from '../components/ScoreFilterPop'
import FilterEditorPop from '../components/FilterEditorPop'
import CaseResultPop from '../components/CaseResultPop'
import FiccChart from '../components/FiccChart'

import { constant, getDateAndTime } from '../mixin/index'
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
	name: 'FICC',

	components: {
		DateFilterPop,
		ScoreFilterPop,
		FilterEditorPop,
		CaseResultPop,
		FiccChart,
	},

	data() {
		return {
			srchDate: '',
			srchTime: '',
			realTimeChartChk: false,

			ficcAssetSelected: 'KTB3YF',


			//activeTab: 'valuesTab',
			visibleDF: false,
			visibleSF: false,
			visibleFE: false,
			visibleCR: false,

			dateFiltered: false,
			mainDateFilterData: {
				filterType: '',
				filterFromDate: '',
				filterToDate: '',
				numFilterSelected: '',
				filterNumbericDate: '',
			},

			scoreFiltered: false,
			mainScoreFilterData: {
				filterType: '',
				filterFromScore: '',
				filterToScore: '',
				numFilterSelected: '',
				filterNumbericScore: '',
			},

			filterEditorTxt: {
				dateFiltered: false,
				dateFilterType: '',
				dateFromValuesTxt: '',
				dateToValuesTxt: '',
				dateNumbericTxt: '',

				scoreFiltered: false,
				scoreFilterType: '',
				scoreFromValuesTxt: '',
				scoreToValuesTxt: '',
				scoreNumbericTxt: '',
			},

			caseResultAlertTxt: '',


			orderByDate: 'desc',
			orderByScore: 'desc',



			chartData: []
		};
	},

	mixins: [constant, getDateAndTime],

	computed: {
		...mapState('ficcStore', {
			ficcAssetOptions: state => state.ficcAssetOptions,
			//ficcDateScoreList: state => state.ficcDateScoreList,
			orgficcDateScoreList: state => state.orgficcDateScoreList,
			ficcCaseResultList: state => state.ficcCaseResultList,
		}),

		...mapGetters('ficcStore', [
			'ficcDateFilterList',
			'ficcScoreFilterList',
			'ficcDateNumFilterList',
		]),

		ficcDateScoreList: function () {
			// DATE / SCORE 필터
			if(this.dateFiltered || this.scoreFiltered) {
				console.log('\n\n\n');
				console.log('ZZZZZZZZZZZZZZZZ this.dateFiltered ::: ', this.dateFiltered);
				console.log('ZZZZZZZZZZZZZZZZ this.scoreFiltered ::: ', this.scoreFiltered);

				// DATE 필터
				if(this.dateFiltered == true && this.scoreFiltered == false) {
					console.log('\n\n\n');
					console.log('######################### DATE FILTERED #########################');

					let ldateFilterType = this.mainDateFilterData.filterType
					console.log('=====> ldateFilterType ::: ', ldateFilterType)

					if(ldateFilterType == 'values') {
						// x : 요소, idx : 인덱스, array : 원 배열
						return this.orgficcDateScoreList.filter( (x, idx, array) => {
							return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
									x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate
						});
					} else if(ldateFilterType == 'numberic') {

						let lnumFilterSelected = this.mainDateFilterData.numFilterSelected
						console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

						if(lnumFilterSelected == '<') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate
							});
						} else if(lnumFilterSelected == '<=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate
							});
						} else if(lnumFilterSelected == '>') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate
							});
						} else if(lnumFilterSelected == '>=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate
							});
						} else {
							return this.orgficcDateScoreList;
						}
					} else {
						return this.orgficcDateScoreList;
					}

				// SCORE 필터
				} else if(this.dateFiltered == false && this.scoreFiltered == true) {
					console.log('\n\n\n');
					console.log('######################### SCORE FILTERED #########################');

					let lscoreFilterType = this.mainScoreFilterData.filterType
					console.log('=====> lscoreFilterType ::: ', lscoreFilterType)

					if(lscoreFilterType == 'values') {
						// x : 요소, idx : 인덱스, array : 원 배열
						return this.orgficcDateScoreList.filter( (x, idx, array) => {
							return x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) && x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
						});
					} else if(lscoreFilterType == 'numberic') {

						let lnumFilterSelected = this.mainScoreFilterData.numFilterSelected
						console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

						if(lnumFilterSelected == '<') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '<=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '>') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '>=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else {
							return this.orgficcDateScoreList
						}
					} else {
						return this.orgficcDateScoreList
					}

				// DATE / SCORE 필터
				} else if(this.dateFiltered == true && this.scoreFiltered == true) {
					console.log('\n\n\n');
					console.log('######################### DATE / SCORE FILTERED #########################');

					let ldateFilterType = this.mainDateFilterData.filterType
					console.log('=====> ldateFilterType ::: ', ldateFilterType)
					let ldateNumFilterSelected = this.mainDateFilterData.numFilterSelected
					console.log('=====> ldateNumFilterSelected ::: ', ldateNumFilterSelected)

					let lscoreFilterType = this.mainScoreFilterData.filterType
					console.log('=====> lscoreFilterType ::: ', lscoreFilterType)
					let lscoreNumFilterSelected = this.mainScoreFilterData.numFilterSelected
					console.log('=====> lscoreNumFilterSelected ::: ', lscoreNumFilterSelected)

					// DATE(Values) ::: SCORE(Values)
					if(ldateFilterType == 'values' && lscoreFilterType == 'values') {
						console.log('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BOTH @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
						// x : 요소, idx : 인덱스, array : 원 배열
						return this.orgficcDateScoreList.filter( (x, idx, array) => {
							return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
									x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate &&
									x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) &&
									x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
						});

					// DATE(Values) ::: SCORE(Numberic)
					} else if(ldateFilterType == 'values' && lscoreFilterType == 'numberic') {

						let lnumFilterSelected = this.mainScoreFilterData.numFilterSelected
						console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

						if(lnumFilterSelected == '<') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
										x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate &&
										x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '<=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
										x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate &&
										x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '>') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
										x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate &&
										x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else if(lnumFilterSelected == '>=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterFromDate &&
										x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterToDate &&
										x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
							});
						} else {
							return this.orgficcDateScoreList
						}

					// DATE(Numberic) ::: SCORE(Values)
					} else if(ldateFilterType == 'numberic' && lscoreFilterType == 'values') {

						let lnumFilterSelected = this.mainDateFilterData.numFilterSelected
						console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

						if(lnumFilterSelected == '<') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate &&
										x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) &&
										x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
							});
						} else if(lnumFilterSelected == '<=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate &&
										x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) &&
										x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
							});
						} else if(lnumFilterSelected == '>') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate &&
										x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) &&
										x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
							});
						} else if(lnumFilterSelected == '>=') {
							return this.orgficcDateScoreList.filter( (x, idx, array) => {
								return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate &&
										x.scoreVal >= Number(this.mainScoreFilterData.filterFromScore) &&
										x.scoreVal <= Number(this.mainScoreFilterData.filterToScore)
							});
						} else {
							return this.orgficcDateScoreList;
						}

					// DATE(Numberic) ::: SCORE(Numberic)
					} else if(ldateFilterType == 'numberic' && lscoreFilterType == 'numberic') {

						let ldateNumFilterSelected = this.mainDateFilterData.numFilterSelected
						console.log('=====> ldateNumFilterSelected ::: ', ldateNumFilterSelected)

						let lscoreNumFilterSelected = this.mainScoreFilterData.numFilterSelected
						console.log('=====> lscoreNumFilterSelected ::: ', lscoreNumFilterSelected)

						if(ldateNumFilterSelected == '<') {
							if(lscoreNumFilterSelected == '<') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '<=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') < this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else {
								return this.orgficcDateScoreList;
							}

						} else if(ldateNumFilterSelected == '<=') {
							if(lscoreNumFilterSelected == '<') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '<=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') <= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else {
								return this.orgficcDateScoreList;
							}

						} else if(ldateNumFilterSelected == '>') {
							if(lscoreNumFilterSelected == '<') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '<=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') > this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else {
								return this.orgficcDateScoreList;
							}

						} else if(ldateNumFilterSelected == '>=') {
							if(lscoreNumFilterSelected == '<') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal < Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '<=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal <= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal > Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else if(lscoreNumFilterSelected == '>=') {
								return this.orgficcDateScoreList.filter( (x, idx, array) => {
									return x.dateVal.replace(/-/g,'') >= this.mainDateFilterData.filterNumbericDate &&
											x.scoreVal >= Number(this.mainScoreFilterData.filterNumbericScore)
								});
							} else {
								return this.orgficcDateScoreList;
							}

						} else {
							return this.orgficcDateScoreList;
						}

					} else {
						console.log('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqq')
						return this.orgficcDateScoreList
					}

				} else {
					return this.orgficcDateScoreList
				}
			} else {
				console.log('iiiiiiiiiiiiiiiiiiii')
				return this.orgficcDateScoreList
			}
		},
	},

	created() {
		this.console = console
	},

	mounted() {
		this.initData()

		let reqParam = { ASSETCATEGORY: 'FICC' }
		this.ficcFetchAssetList( {reqParam} )
    },

	methods: {
		...mapActions('ficcStore', [
			'ficcFetchAssetList',
			'ficcFetchDateScoreList',
			'ficcFetchCaseResultList',
			'ficcFetchCaseResultListTEST',
			'ficcFetchCaseResultListTEST2',
		]),

		initData: function() {
			let dateTime = this.getDateAndTime()
			this.srchDate = dateTime.substr(2, 8)
			this.srchTime = dateTime.substr(11, 5)
		},

		searchRun: function() {
			let valChkDate = this.srchDate.replace(/-/g,'')
			if(valChkDate == null || valChkDate == '' || valChkDate.length != 6) {
				alert("DATE를 확인해주세요.")
				return;
			}

			let valChkTime = this.srchTime.replace(':','')
			if(valChkTime == null || valChkTime == '' || valChkTime.length != 4) {
				alert("TIME를 확인해주세요.")
				return;
			}

			let valChkAsset = this.ficcAssetSelected
			if(valChkAsset == null || valChkAsset == '') {
				alert("ASSET를 확인해주세요.")
				return;
			}


			// DATE 필터 데이타 초기화
			this.resetDateFilterData()

			// SCORE 필터 데이타 초기화
			this.resetScoreFilterData()


			let valAsset = this.ficcAssetSelected
			//console.log("methods >>> valAsset ::: ", valAsset);

			let sendDateTime = '20' + valChkDate + valChkTime

			let reqParam = {
				asset: valAsset,
				sendDateTime: sendDateTime,
			}
			this.ficcFetchDateScoreList( {reqParam} )
			this.ficcFetchCaseResultList( {reqParam} )
		},

		openDateFilter() {
			this.visibleDF = !this.visibleDF

			// DATE FILTER POPUP의 함수 호출
			this.$refs.datefilterpop.initData()
		},

		doDateFilter(pfilterData) {
			console.log('>>>>> doDateFilter ::: 팝업에서 받은 필터 데이타 ::: ', pfilterData)

			this.dateFiltered = true

			const cloneObj = obj => JSON.parse(JSON.stringify(obj))
			this.mainDateFilterData = cloneObj(pfilterData)
			console.log('>>>>> doDateFilter ::: this.mainDateFilterData ::: ', this.mainDateFilterData)


			// DATE 포맷이 변경되면서 수정
			// this.mainDateFilterData.filterFromDate = '20' + pfilterData.filterFromDate.replace(/-/g, '')
			// this.mainDateFilterData.filterToDate = '20' + pfilterData.filterToDate.replace(/-/g, '')
			this.mainDateFilterData.filterFromDate = pfilterData.filterFromDate.replace(/-/g, '')
			this.mainDateFilterData.filterToDate = pfilterData.filterToDate.replace(/-/g, '')


			// Filter Editor 텍스트 설정
			let ldateFilterType = this.mainDateFilterData.filterType
			console.log('=====> ldateFilterType ::: ', ldateFilterType);

			this.filterEditorTxt.dateFiltered = true
			this.filterEditorTxt.dateFilterType = ldateFilterType

			if(ldateFilterType == 'values') {
				let ldateFrVal = this.to_date_format(this.mainDateFilterData.filterFromDate, '-')
				let ldateToVal = this.to_date_format(this.mainDateFilterData.filterToDate, '-')

				this.filterEditorTxt.dateFromValuesTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[3].text + ldateFrVal
				this.filterEditorTxt.dateToValuesTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[1].text + ldateToVal
				console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))

			} else if(ldateFilterType == 'numberic') {

				let lnumFilterSelected = this.mainDateFilterData.numFilterSelected
				console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

				let ldateVal = this.to_date_format(this.mainDateFilterData.filterNumbericDate, '-')

				if(lnumFilterSelected == '<') {
					this.filterEditorTxt.dateNumbericTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[0].text + ldateVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '<=') {
					this.filterEditorTxt.dateNumbericTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[1].text + ldateVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '>') {
					this.filterEditorTxt.dateNumbericTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[2].text + ldateVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '>=') {
					this.filterEditorTxt.dateNumbericTxt = this.filterEditorDatePrefix + this.filterEditorMiddle[3].text + ldateVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				}
			}
		},

		resetDateFilterData() {
			this.dateFiltered = false

			this.mainDateFilterData.filterType = ''
			this.mainDateFilterData.filterFromDate = ''
			this.mainDateFilterData.filterToDate = ''
			this.mainDateFilterData.numFilterSelected = ''
			this.mainDateFilterData.filterNumbericDate = ''
			console.log('>>>>> resetDateFilterData ::: this.mainDateFilterData ::: ', this.mainDateFilterData)


			this.filterEditorTxt.dateFiltered = false
			this.filterEditorTxt.dateFilterType = ''
			this.filterEditorTxt.dateFromValuesTxt = ''
			this.filterEditorTxt.dateToValuesTxt = ''
			this.filterEditorTxt.dateNumbericTxt = ''
			console.log('>>>>> resetDateFilterData ::: this.filterEditorTxt ::: ', this.filterEditorTxt)
		},


		openScoreFilter() {
			this.visibleSF = !this.visibleSF

			// SCORE FILTER POPUP의 함수 호출
			this.$refs.scorefilterpop.initData()
		},

		doScoreFilter(pfilterData) {
			console.log('>>>>> doScoreFilter ::: 팝업에서 받은 필터 데이타 ::: ', pfilterData)

			this.scoreFiltered = true;

			const cloneObj = obj => JSON.parse(JSON.stringify(obj))
			this.mainScoreFilterData = cloneObj(pfilterData)
			console.log('>>>>> doScoreFilter ::: this.mainScoreFilterData ::: ', this.mainScoreFilterData)

			// Filter Editor 텍스트 설정
			let lscoreFilterType = this.mainScoreFilterData.filterType
			console.log('=====> lscoreFilterType ::: ', lscoreFilterType)

			this.filterEditorTxt.scoreFiltered = true
			this.filterEditorTxt.scoreFilterType = lscoreFilterType

			if(lscoreFilterType == 'values') {
				let lscoreFrVal = this.mainScoreFilterData.filterFromScore
				let lscoreToVal = this.mainScoreFilterData.filterToScore

				this.filterEditorTxt.scoreFromValuesTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[3].text + lscoreFrVal
				this.filterEditorTxt.scoreToValuesTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[1].text + lscoreToVal
				console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))

			} else if(lscoreFilterType == 'numberic') {

				let lnumFilterSelected = this.mainScoreFilterData.numFilterSelected
				console.log('=====> lnumFilterSelected ::: ', lnumFilterSelected)

				let lscoreVal = this.mainScoreFilterData.filterNumbericScore

				if(lnumFilterSelected == '<') {
					this.filterEditorTxt.scoreNumbericTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[0].text + lscoreVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '<=') {
					this.filterEditorTxt.scoreNumbericTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[1].text + lscoreVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '>') {
					this.filterEditorTxt.scoreNumbericTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[2].text + lscoreVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				} else if(lnumFilterSelected == '>=') {
					this.filterEditorTxt.scoreNumbericTxt = this.filterEditorScorePrefix + this.filterEditorMiddle[3].text + lscoreVal
					console.log('>>>>> this.filterEditorTxt ::: ', JSON.stringify(this.filterEditorTxt))
				}
			}
		},

		resetScoreFilterData() {
			this.scoreFiltered = false

			this.mainScoreFilterData.filterType = ''
			this.mainScoreFilterData.filterFromScore = ''
			this.mainScoreFilterData.filterToScore = ''
			this.mainScoreFilterData.numFilterSelected = ''
			this.mainScoreFilterData.filterNumbericScore = ''
			console.log('>>>>> resetScoreFilterData ::: this.mainScoreFilterData ::: ', this.mainScoreFilterData)


			this.filterEditorTxt.scoreFiltered = false
			this.filterEditorTxt.scoreFilterType = ''
			this.filterEditorTxt.scoreFromValuesTxt = ''
			this.filterEditorTxt.scoreToValuesTxt = ''
			this.filterEditorTxt.scoreNumbericTxt = ''
			console.log('>>>>> resetDateFilterData ::: this.filterEditorTxt ::: ', this.filterEditorTxt)
		},


		openFilterEditor() {
			console.log('>>>>> openFilterEditor ::: ')
			console.log('>>>>> this.visibleFE ::: ', this.visibleFE)
			this.visibleFE = !this.visibleFE
		},


		// 메인화면 전체 필터 해제
		resetAllFilterData() {
			// this.resetDateFilterData()
			// this.resetScoreFilterData()

			// DATE FILTER POPUP의 함수 호출
			this.$refs.datefilterpop.resetFilterData()

			// SCORE FILTER POPUP의 함수 호출
			this.$refs.scorefilterpop.resetFilterData()
		},


		itemRowBackground: function(category, item) {
			// console.log("methods >>> category ::: " + category + "   >>> item ::: " + item);

			if(category == 'CASE UP') {
				if(item > 50) {
					return 'background-color:red';
				} else {
					return '';
				}
			} else if(category == 'CASE DOWN') {
				if(item > 50) {
					return 'background-color:blue';
				} else {
					return '';
				}
			} else {
				return '';
			}
		},

		// DATE 포맷이 변경되면서 수정
		// to_date_format(date_str, gubun) {
		// 	var yyyyMMdd = String(date_str);
		// 	var sYear = yyyyMMdd.substring(2,4);
		// 	var sMonth = yyyyMMdd.substring(4,6);
		// 	var sDate = yyyyMMdd.substring(6,8);

		// 	return sYear + gubun + sMonth + gubun + sDate;
		// },
		to_date_format(date_str, gubun) {
			var yyMMdd = String(date_str);
			var sYear = yyMMdd.substring(0,2);
			var sMonth = yyMMdd.substring(2,4);
			var sDate = yyMMdd.substring(4,6);

			return sYear + gubun + sMonth + gubun + sDate;
		},

		clickHeader() {
			console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
		},

		headerClick(arg) {
			console.log('ooooooooooooooooooooooooooooooooooo')
			console.log('arg ::: ', arg)

			if(this.ficcDateScoreList.length > 0) {
				if(arg == 'date') {
					if(this.orderByDate == 'asc') {
						this.orderByDate = 'desc'
					} else if(this.orderByDate == 'desc') {
						this.orderByDate = 'asc'
					} else {
						this.orderByDate = 'desc'
					}
				} else if(arg == 'score') {
					if(this.orderByScore == 'asc') {
						this.orderByScore = 'desc'
					} else if(this.orderByScore == 'desc') {
						this.orderByScore = 'asc'
					} else {
						this.orderByScore = 'desc'
					}
				} else {
					this.orderByDate = 'desc'
					this.orderByScore = 'desc'
				}
			}
		},

		setCaseResultTest() {
			console.log('+++++++++++++++ setCaseResultTest +++++++++++++++')
			let reqParam = {
				asset: 'KTB10YF',
				sendDateTime: '202102191430',
			}
			this.ficcFetchCaseResultListTEST( {reqParam} )
		},
		setCaseResultTest2() {
			console.log('+++++++++++++++ setCaseResultTest2 +++++++++++++++')
			let reqParam = {
				asset: 'KTB10YF',
				sendDateTime: '202102191430',
			}
			this.ficcFetchCaseResultListTEST2( {reqParam} )
		},
	},

	watch: {
		ficcCaseResultList(newVal, oldVal) {
			console.log('==================== [watch] ====================')
			console.log('newVal ::: ', newVal)
			console.log('oldVal ::: ', oldVal)

			let arrAlertMsg = [];

			let up0D1HVal = [];
			let up0D2HVal = [];
			let up0D3HVal = [];
			let up0D4HVal = [];
			let up0D5HVal = [];
			let up0D6HVal = [];
			let up1D0HVal = [];
			let up2D0HVal = [];

			let dw0D1HVal = [];
			let dw0D2HVal = [];
			let dw0D3HVal = [];
			let dw0D4HVal = [];
			let dw0D5HVal = [];
			let dw0D6HVal = [];
			let dw1D0HVal = [];
			let dw2D0HVal = [];

			for(let i = 0; i < oldVal.length; i++) {

				// CASE UP
				if(i == 0) {
					console.log('>>>>> CASE UP <<<<<')

					if(oldVal[i].result0D1HVal != '-') {
						up0D1HVal.push(oldVal[i].result0D1HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D1HVal.push(newVal[j].result0D1HVal)
						}
					}
					if(oldVal[i].result0D2HVal != '-') {
						up0D2HVal.push(oldVal[i].result0D2HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D2HVal.push(newVal[j].result0D2HVal)
						}
					}
					if(oldVal[i].result0D3HVal != '-') {
						up0D3HVal.push(oldVal[i].result0D3HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D3HVal.push(newVal[j].result0D3HVal)
						}
					}
					if(oldVal[i].result0D4HVal != '-') {
						up0D4HVal.push(oldVal[i].result0D4HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D4HVal.push(newVal[j].result0D4HVal)
						}
					}
					if(oldVal[i].result0D5HVal != '-') {
						up0D5HVal.push(oldVal[i].result0D5HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D5HVal.push(newVal[j].result0D5HVal)
						}
					}
					if(oldVal[i].result0D6HVal != '-') {
						up0D6HVal.push(oldVal[i].result0D6HVal)
						for(let j = 0; j < newVal.length; j++) {
							up0D6HVal.push(newVal[j].result0D6HVal)
						}
					}
					if(oldVal[i].result1D0HVal != '-') {
						up1D0HVal.push(oldVal[i].result1D0HVal)

						for(let j = 0; j < newVal.length; j++) {
							up1D0HVal.push(newVal[j].result1D0HVal)
						}
					}
					if(oldVal[i].result2D0HVal != '-') {
						up2D0HVal.push(oldVal[i].result2D0HVal)

						for(let j = 0; j < newVal.length; j++) {
							up2D0HVal.push(newVal[j].result2D0HVal)
						}
					}

				// CASE DOWN
				} else {
					console.log('>>>>> CASE DOWN <<<<<')

					if(oldVal[i].result0D1HVal != '-') {
						dw0D1HVal.push(oldVal[i].result0D1HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D1HVal.push(newVal[j].result0D1HVal)
						}
					}
					if(oldVal[i].result0D2HVal != '-') {
						dw0D2HVal.push(oldVal[i].result0D2HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D2HVal.push(newVal[j].result0D2HVal)
						}
					}
					if(oldVal[i].result0D3HVal != '-') {
						dw0D3HVal.push(oldVal[i].result0D3HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D3HVal.push(newVal[j].result0D3HVal)
						}
					}
					if(oldVal[i].result0D4HVal != '-') {
						dw0D4HVal.push(oldVal[i].result0D4HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D4HVal.push(newVal[j].result0D4HVal)
						}
					}
					if(oldVal[i].result0D5HVal != '-') {
						dw0D5HVal.push(oldVal[i].result0D5HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D5HVal.push(newVal[j].result0D5HVal)
						}
					}
					if(oldVal[i].result0D6HVal != '-') {
						dw0D6HVal.push(oldVal[i].result0D6HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw0D6HVal.push(newVal[j].result0D6HVal)
						}
					}
					if(oldVal[i].result1D0HVal != '-') {
						dw1D0HVal.push(oldVal[i].result1D0HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw1D0HVal.push(newVal[j].result1D0HVal)
						}
					}
					if(oldVal[i].result2D0HVal != '-') {
						dw2D0HVal.push(oldVal[i].result2D0HVal)
						for(let j = 0; j < newVal.length; j++) {
							dw2D0HVal.push(newVal[j].result2D0HVal)
						}
					}
				}
			}

			//up1D0HVal ::: ["49.95", "51", "49"]
			//up2D0HVal ::: ["54.13", "49", "51"]
			//dw1D0HVal ::: ["50.04", "51", "49"]
			//dw2D0HVal ::: ["45.86", "49", "51"]
			let lMsg = ''
			if(up0D1HVal[0] > 50 && up0D1HVal[1] < 50) {
				lMsg = '[0D+1H] 상승예상(' +  up0D1HVal[0] + ') -> 하락예상(' + up0D1HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D1HVal ::: ', arrAlertMsg)
			}
			if(up0D2HVal[0] > 50 && up0D2HVal[1] < 50) {
				lMsg = '[0D+2H] 상승예상(' +  up0D2HVal[0] + ') -> 하락예상(' + up0D2HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D2HVal ::: ', arrAlertMsg)
			}
			if(up0D3HVal[0] > 50 && up0D3HVal[1] < 50) {
				lMsg = '[0D+3H] 상승예상(' +  up0D3HVal[0] + ') -> 하락예상(' + up0D3HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D3HVal ::: ', arrAlertMsg)
			}
			if(up0D4HVal[0] > 50 && up0D4HVal[1] < 50) {
				lMsg = '[0D+4H] 상승예상(' +  up0D4HVal[0] + ') -> 하락예상(' + up0D4HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D4HVal ::: ', arrAlertMsg)
			}
			if(up0D5HVal[0] > 50 && up0D5HVal[1] < 50) {
				lMsg = '[0D+5H] 상승예상(' +  up0D5HVal[0] + ') -> 하락예상(' + up0D5HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D5HVal ::: ', arrAlertMsg)
			}
			if(up0D6HVal[0] > 50 && up0D6HVal[1] < 50) {
				lMsg = '[0D+6H] 상승예상(' +  up0D6HVal[0] + ') -> 하락예상(' + up0D6HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D6HVal ::: ', arrAlertMsg)
			}
			if(up1D0HVal[0] > 50 && up1D0HVal[1] < 50) {
				lMsg = '[1D+0H] 상승예상(' +  up1D0HVal[0] + ') -> 하락예상(' + up1D0HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up1D0HVal ::: ', arrAlertMsg)
			}
			if(up2D0HVal[0] > 50 && up2D0HVal[1] < 50) {
				lMsg = '[2D+0H] 상승예상(' +  up2D0HVal[0] + ') -> 하락예상(' + up2D0HVal[2] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up2D0HVal ::: ', arrAlertMsg)
			}


			if(dw0D1HVal[0] > 50 && dw0D1HVal[2] < 50) {
				lMsg = '[0D+1H] 하락예상(' +  dw0D1HVal[0] + ') -> 상승예상(' + dw0D1HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: up0D1HVal ::: ', arrAlertMsg)
			}
			if(dw0D2HVal[0] > 50 && dw0D2HVal[2] < 50) {
				lMsg = '[0D+2H] 하락예상(' +  dw0D2HVal[0] + ') -> 상승예상(' + dw0D2HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw0D2HVal ::: ', arrAlertMsg)
			}
			if(dw0D3HVal[0] > 50 && dw0D3HVal[2] < 50) {
				lMsg = '[0D+3H] 하락예상(' +  dw0D3HVal[0] + ') -> 상승예상(' + dw0D3HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw0D3HVal ::: ', arrAlertMsg)
			}
			if(dw0D4HVal[0] > 50 && dw0D4HVal[2] < 50) {
				lMsg = '[0D+4H] 하락예상(' +  dw0D4HVal[0] + ') -> 상승예상(' + dw0D4HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw0D4HVal ::: ', arrAlertMsg)
			}
			if(dw0D5HVal[0] > 50 && dw0D5HVal[2] < 50) {
				lMsg = '[0D+5H] 하락예상(' +  dw0D5HVal[0] + ') -> 상승예상(' + dw0D5HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw0D5HVal ::: ', arrAlertMsg)
			}
			if(dw0D6HVal[0] > 50 && dw0D6HVal[2] < 50) {
				lMsg = '[0D+6H] 하락예상(' +  dw0D6HVal[0] + ') -> 상승예상(' + dw0D6HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw0D6HVal ::: ', arrAlertMsg)
			}
			if(dw1D0HVal[0] > 50 && dw1D0HVal[2] < 50) {
				lMsg = '[1D+0H] 하락예상(' +  dw1D0HVal[0] + ') -> 상승예상(' + dw1D0HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw1D0HVal ::: ', arrAlertMsg)
			}
			if(dw2D0HVal[0] > 50 && dw2D0HVal[2] < 50) {
				lMsg = '[2D+0H] 하락예상(' +  dw2D0HVal[0] + ') -> 상승예상(' + dw2D0HVal[1] + ')'
				arrAlertMsg.push(lMsg)
				console.log('arrAlertMsg ::: dw2D0HVal ::: ', arrAlertMsg)
			}


			let strAlertMsg = ''
			if(arrAlertMsg.length > 0) {
				arrAlertMsg.forEach((alert) => {
					strAlertMsg += alert + '<br />'
				});

				//alert(strAlertMsg)

				//console.log('>>>>> this.visibleCR ::: ', this.visibleCR)
				this.visibleCR = !this.visibleCR
				this.caseResultAlertTxt = strAlertMsg


				// var audio = new Audio("../assets/alert.wav3")
				// var audio = new Audio('file://C:/Portal/KBDAM/dtproject-cdfront/src/assets/alert.wav3')

				// var audio = new Audio("http://soundbible.com/mp3/Air Plane Ding-SoundBible.com-496729130.mp3")
				// var audio = new Audio("http://soundbible.com/mp3/Elevator Ding-SoundBible.com-685385892.mp3")

				// var audio = new Audio("http://localhost:8080/AirPlaneDing.mp3")
				var audio = new Audio("http://localhost:8080/ElevatorDing.mp3")

				audio.volume = 1
				audio.play()
			}
		},
	},
};
</script>

<style scoped>
.tabs {
	flex: 0 !important;
}


/* .inputPrice input[type='number'] {
	-moz-appearance:textfield;
}
.inputPrice input::-webkit-outer-spin-button,
.inputPrice input::-webkit-inner-spin-button {
	-webkit-appearance: none;
} */


table {
	width: 100%;
	border: 1px solid #444444;
	border-collapse: collapse;
}
th, td {
	border: 1px solid #444444;
	padding: 10px;
}


.style-1 {
	background-color: rgb(215, 215, 44)
}
.style-2 {
	background-color: rgb(114, 114, 67)
}


.v-data-table header {
	font-size: 14px;
}
.v-data-table th {
	font-size: 12px;
}
.v-data-table td {
	font-size: 12px;
}
</style>
