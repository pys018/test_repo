<template>
    <v-app>

		<div>
			<v-simple-table >
				<tbody>
					<tr>
						<td width="99%" class="text-center">
							FICC
						</td>
						<td width="1%" class="text-center">
							???
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-simple-table dense border="1">
								<tbody>
									<tr>
										<td></td>
										<td>DATE(로컬)</td>
										<td>
											<v-text-field
												v-mask="'##-##-##'"
												v-model="srchDate"
												label=""
												persistent-hint
												placeholder="YY-MM-DD"
											></v-text-field>
										</td>
										<td></td>
										<td>TIME(로컬)</td>
										<td>
											<v-text-field
												v-mask="'##:##'"
												v-model="srchTime"
												label=""
												persistent-hint
												placeholder="HH:MM"
											></v-text-field>
										</td>
										<td></td>
										<td>ASSET</td>
										<td>
											<v-autocomplete
												v-model="assetSelected"
												:items="assetOptions"
												label=""
												chips
												color="blue"
											>
											</v-autocomplete>
										</td>
										<td></td>
										<td>OFFSET</td>
										<td>
											<v-select
												v-model="offsetSelected"
												:items="offsetOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td>
											<v-btn block v-on:click="searchRun">
												실행
											</v-btn>
										</td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td>
											<v-checkbox v-model="realTimeChartChk">
												<template v-slot:label>
													<div>
														RealTime Chart
													</div>
												</template>
											</v-checkbox>
										</td>
										<td></td>
										<td></td>
										<td>
											<v-select
												v-model="refreshSelected"
												:items="refreshOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td>
											<v-select
												v-model="xaxisUnitSelected"
												:items="xaxisUnitOptions"
												label=""
											></v-select>
										</td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
								</tbody>
							</v-simple-table>
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-simple-table dense border="1">
								<tbody>
									<tr>
										<td width="74%">
											<!-- <chart
											:options="bar"
											:init-options="initOptions"
											ref="bar"
											theme="ovilia-green"
											autoresize
											/> -->
										</td>
										<td width="1%"></td>
										<td width="25%">
											<v-text-field v-model="dateScoreSearch" single-line></v-text-field>
											<v-data-table
												:headers="dateScoreHeaders"
												:items="dateScoreDatas"
												class="elevation-1"
												:items-per-page="100"
												hide-default-footer
												:search="dateScoreSearch"
											></v-data-table>
										</td>
									</tr>
								</tbody>
							</v-simple-table>
						</td>
					</tr>

					<tr>
						<td colspan="2">
							▣ CASE FICC Result
						</td>
					</tr>

					<tr>
						<td colspan="2">
							<v-data-table
								:headers="caseResultHeaders"
								:items="caseResultDatas"
								class="elevation-1"
								hide-default-footer
								@click:row="clickRow"
								@dblclick:row="dblclickRow"
							>
								<template v-slot:item="{ item }">
									<tr>
										<td >{{ item.resultCategoryVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D1HVal)">{{ item.result0D1HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D2HVal)">{{ item.result0D2HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D3HVal)">{{ item.result0D3HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D4HVal)">{{ item.result0D4HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D5HVal)">{{ item.result0D5HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result0D6HVal)">{{ item.result0D6HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result1D0HVal)">{{ item.result1D0HVal }}</td>
										<td :style="itemRowBackground(item.resultCategoryVal,item.result2D0HVal)">{{ item.result2D0HVal }}</td>
									</tr>
								</template>
							</v-data-table>
						</td>
					</tr>

					<tr>
						<td colspan="2">
							666
						</td>
					</tr>
				</tbody>

			</v-simple-table>
		</div>

    </v-app>
</template>

<script>
import axios from 'axios';

export default {
    name: 'page1',
    components: {

    },

    data: vm => ({
        msg: 'ZZZZZ',

        assetSelected: 'KTB3YF',
        assetOptions: [
            { text: 'KTB3YF', value: 'KTB3YF' },
            { text: 'KTB10YF', value: 'KTB10YF' },
            { text: 'UST2YF', value: 'UST2YF' },
            { text: 'UST5YF', value: 'UST5YF' },
            { text: 'UST10YF', value: 'UST10YF' },
            { text: 'USDKRWF', value: 'USDKRWF' },
            { text: 'EURKRWF', value: 'EURKRWF' },
            { text: 'JPYKRWF', value: 'JPYKRWF' },
        ],

        offsetSelected: 'N',
        offsetOptions: [
            { text: 'Now Price', value: 'N' },
            { text: 'Close Price', value: 'C' },
        ],

        refreshSelected: '30',
        refreshOptions: [
            { text: 'Refresh 5min', value: '5' },
            { text: 'Refresh 10min', value: '10' },
            { text: 'Refresh 30min', value: '30' },
            { text: 'Refresh 60min', value: '60' },
        ],

        xaxisUnitSelected: '30',
        xaxisUnitOptions: [
            { text: '5min', value: '5' },
            { text: '10min', value: '10' },
            { text: '30min', value: '30' },
            { text: '60min', value: '60' },
            { text: '1day', value: '1D' },
        ],

        srchDate: '',

        srchTime: '',

        realTimeChartChk: false,

        dateScoreSearch: '',
        dateScoreHeaders: [
            {
                text: 'DATE',
                align: 'start',
                sortable: true,
                value: 'dateVal',
            },
            {
                text: 'Score',
                value: 'scoreVal',
            },
        ],
 

        caseResultHeaders: [
            {
                text: 'Category',
                align: 'start',
                sortable: false,
                value: 'resultCategoryVal',
            },
            {
                text: '0D+1H',
                sortable: false,
                value: 'result0D1HVal',
            },
            {
                text: '0D+2H',
                sortable: false,
                value: 'result0D2HVal',
            },
            {
                text: '0D+3H',
                sortable: false,
                value: 'result0D3HVal',
            },
            {
                text: '0D+4H',
                sortable: false,
                value: 'result0D4HVal',
            },
            {
                text: '0D+5H',
                sortable: false,
                value: 'result0D5HVal',
            },
            {
                text: '0D+6H',
                sortable: false,
                value: 'result0D6HVal',
            },
            {
                text: '1D+0H',
                sortable: false,
                value: 'result1D0HVal',
            },
            {
                text: '2D+0H',
                sortable: false,
                value: 'result2D0HVal',
            },
        ],
        caseResultDatas: [
            {
                resultCategoryVal: 'CASE UP',
                result0D1HVal: '-',
                result0D2HVal: '-',
                result0D3HVal: '-',
                result0D4HVal: '-',
                result0D5HVal: '-',
                result0D6HVal: '-',
                result1D0HVal: '49.95',
                result2D0HVal: '54.13',
            },
            {
                resultCategoryVal: 'CASE DOWN',
                result0D1HVal: '-',
                result0D2HVal: '-',
                result0D3HVal: '-',
                result0D4HVal: '-',
                result0D5HVal: '-',
                result0D6HVal: '-',
                result1D0HVal: '50.04',
                result2D0HVal: '45.86',
            },
        ],
    }),

    computed: {
        computedDateFormatted () {
            return this.formatDate(this.date)
        },
    },

    watch: {
        date (val) {
            console.log(">>>>> watch >>> this.date ::: " + this.date);
            this.dateFormatted = this.formatDate(this.date)
        },
    },

    mounted() {
        //this.loadData()
        this.initData()
    },

    methods: {
        // loadData : async function () {
        //     try {
        //         const response = await backend.get(`/deep-learning/assetwise/${this.$route.params.assetClass}/recent`)
        //         this.analysis = response.data
        //     } catch (err) {
        //         console.error('API Error')
        //     }
        // },

        test: function(param) {
            console.log('>>>>> test ::: ' + param)
        },

        formatDate (date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${year}-${month}-${day}`
        },
        parseDate (date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${year}-${month}-${day}`
        },


        initData: function(param) {
            let offset = new Date().getTimezoneOffset() * 60000;
            let today = new Date(Date.now() - offset);
            console.log(">>>>> today 111 ::: " + today);
            today = today.toISOString();
            console.log(">>>>> today 222 ::: " + today);
            this.srchDate = today.substr(2, 8);

            this.srchTime = today.substr(11, 5);
        },

        searchRun: function() {
            let valChkDate = this.srchDate.replace(/-/g,'');
            console.log("methods >>> valChkDate ::: ", valChkDate);
            if(valChkDate == null || valChkDate == '' || valChkDate.length != 6) {
                alert("DATE를 확인해주세요.");
                return;
            }

            let valChkTime = this.srchTime.replace(':','');
            console.log("methods >>> valChkTime ::: ", valChkTime);
            if(valChkTime == null || valChkTime == '' || valChkTime.length != 4) {
                alert("TIME를 확인해주세요.");
                return;
			}

            let valAsset = this.assetSelected;
            console.log("methods >>> valAsset ::: ", valAsset);
            if(valAsset == null || valAsset == '' || valAsset.length != 4) {
                alert("ASSET를 확인해주세요.");
                return;
			}

			let valChkAsset = this.assetSelected;
            console.log("methods >>> valChkAsset ::: ", valChkAsset);

			// validation 끝나고
			let frm = new FormData()
			frm.append('srchDate', '20' + valChkDate)
			frm.append('srchTime', valChkTime)
			frm.append('assetSelected', valChkAsset)
			console.log("methods >>> frm ::: ", frm);

			let sendDateTime = '20' + valChkDate + valChkTime;
			let sendData = "";
			sendData = sendData + "sendDateTime=" + sendDateTime;
			sendData = sendData + "&asset=" + valChkAsset;
			console.log("methods >>> sendData ::: ", sendData);

			axios.get('http://10.17.115.183:8082/api/formal_mp/DAM_FORMAL_MP_S01', sendData, {
				headers: {
					'Access-Control-Allow-Origin': '*',
					'Content-Type': 'application/json; charset = utf-8',
				},
			})
			.then((res, err) => {
				if(err) {
					console.log(err);
				} else {
					console.log(res);
				}
			});
        },

        itemRowBackground: function(category, item) {
            // console.log("methods >>> category ::: " + category + "   >>> item ::: " + item);

            if(category == 'CASE UP') {
                if(item >= 50) {
                    return 'background-color:red';
                } else {
                    return '';
                }
            } else if(category == 'CASE DOWN') {
                if(item >= 50) {
                    return 'background-color:blue';
                } else {
                    return '';
                }
            } else {
                return '';
            }
        },

        dblclickRow() {
            console.log("rowDoubleClicked");
        },
        clickRow() {
            console.log("rowClicked");
        }
    },
};
</script>

<style scoped>
/* .inputPrice input[type='number'] {
    -moz-appearance:textfield;
}
.inputPrice input::-webkit-outer-spin-button,
.inputPrice input::-webkit-inner-spin-button {
    -webkit-appearance: none;
} */



table {
    width: 100%;
    border: 1px solid #444444;
    border-collapse: collapse;
}
th, td {
    border: 1px solid #444444;
    padding: 10px;
}



.style-1 {
    background-color: rgb(215, 215, 44)
}
.style-2 {
    background-color: rgb(114, 114, 67)
}



.v-data-table header {
	font-size: 14px;
}
.v-data-table th {
	font-size: 12px;
}
.v-data-table td {
	font-size: 12px;
}
</style>
