<template>
	<v-app>
		Page2
		<button @click="move()">go to page3</button>
	</v-app>
</template>

<script>
export default {
    name: 'page2',
    data() {
        return {

        };
    },
    mounted() {

    },
    methods: {
        move : function() {
            this.$router.push({path:'page3'})
        }
    },
};
</script>

<style>

</style>
