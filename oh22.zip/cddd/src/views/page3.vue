<template>
    <div>
        Page3
        <div>
            count : {{cnt}}
            count2 : {{cntt}}
            {{reversedMessage}}
            {{getTodoById(2).id}}
        </div>
        <button @click="increment2(4)">눌러라ㅏㅏ</button>
        <button @click="imcrement3()">눌러라ㅏㅏ</button>
    </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
    name: 'page3',
    data() {
        return {
            msg: '안녕하세요'
        };
    },
    computed:{
        ...mapState({
            cnt: 'count',
            cntt: 'count2'
        }),
        ...mapGetters([
            'doneTodos',
            'getTodoById'
        ]),

        reversedMessage: function () {
            return this.msg.split('').reverse().join('')
        }
    },
    mounted() {
        
    },
    methods: {
        ...mapActions([
            'increment',
            'increment2',
            'imcrement3'
        ]),
    },
};
</script>

<style>

</style>