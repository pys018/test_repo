
var emphasisStyle = {
    itemStyle: {
        barBorderWidth: 1,
        shadowBlur: 10,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowColor: 'rgba(0,0,0,0.5)'
    }
};




option = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'cross',
            crossStyle: {
                color: '#999'
            }
        },
        //formatter: function (params) {
          //return `${params.value}: ${params.data.time}`;
        //}
        formatter: '{b2} 20210110 1330 <br> {a2} :: {c2} <br> {a3} :: {c3}',
        //formatter: function(params) {
          //return echarts.format.formatTime('yyyy-MM-dd', params.value);
        //}
    },
    toolbox: {
        feature: {
            //dataView: {show: true, readOnly: false},
            //magicType: {show: true, type: ['line', 'bar']},
            //restore: {show: true},
            //saveAsImage: {show: true},

            dataZoom: {
                yAxisIndex: 'none'
            },
            restore: {},
        }
    },
    legend: {
        data: ['20190711', '20201112']   // ����Ʈ�� ǥ�� ����
    },
    xAxis: [
        {
            type: 'category',
            data: ['-45', '-40', '-35', '-30', '-25', '-20', '-15', '-10', '-5', '0', '5', '10', '15', '20', '25', '30', '35', '40'],
            axisPointer: {
                type: 'shadow'
            },
            splitLine: {
                show: true
            },
            boundaryGap: false,
            axisLine: {onZero: true},
            //splitLine: {show: false},
            splitArea: {show: false},
        }
    ],
    yAxis: [
        // BAR 1
        {
            type: 'value',
            name: 'Price',
            min: -2,
            max: 0.8,
            interval: 50,
            axisLabel: {
                formatter: '{value}'
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%'],
            inverse: false,
            splitArea: {show: false}
        },
        // BAR 2
        {
            type: 'value',
            name: 'Price',
            min: -2,
            max: 0.8,
            interval: 50,
            axisLabel: {
                formatter: '{value}'
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
        // LINE 1 -- 20190711
        {
            type: 'value',
            name: '',
            min: -2,
            max: 0.8,
            interval: 5,
            axisLabel: {
                //formatter: '{value} ��C',
                lineHeight: 1,
                color: "#cc3010",
            },
            axisLine: {
                show: false,
                lineStyle: {
                    color: "#061736",
                    height: 10
                }
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
        // LINE 2 -- 20201112
        {
            type: 'value',
            name: '',
            min: -2,
            max: 0.8,
            interval: 5,
            axisLabel: {
                //formatter: '{value} ��C',
                lineHeight: 1,
                color: "#cc3010",
            },
            axisLine: {
                show: false,
                lineStyle: {
                    color: "#6E7079",
                    height: 10
                }
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
    ],

    dataZoom: [{
        type: 'inside',
        start: 0,
        end: 100
    }, {
        start: 0,
        end: 100
    }],

    series: [
        {
            name: '��?��',
            type: 'bar',
            stack: 'one',
            emphasis: emphasisStyle,
            data: [0, 0, 0, 0, 0, 0.8, 0, 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 0, 0],  // ���� �ְ�������...
            barWidth: 3,
            color: "#cc3010",
        },
        {
            name: '��?��2',
            type: 'bar',
            stack: 'one',
            emphasis: emphasisStyle,
            data: [0, 0, 0, 0, 0, -2, 0, 0, 0, -2, 0, 0, 0, 0, 0, 0, 0, 0],  // ���� ����������...
            barWidth: 3,
            color: "#cc3010",
        },
        {
            name: '20190711',
            type: 'line',
            yAxisIndex: 2,
            data: [-0.6, -0.2, -0.1, -0.7, -0.4, -0.3, -0.6, -0.1, 0, 0.2, 0.4, 0.7, -0.2, -0.5, 0.3, 0.4, 0.1, -0.3],
            lineStyle: {
                color: "#061736",
                width: 2
            }
        },
        {
            name: '20201112',
            type: 'line',
            yAxisIndex: 1,
            data: [-1.6, -1.2, -1.3, -1.0, -1.2, -1.1, 0.1, 0.3, 0.5, 0.3],    // �ƿ� ���� ���� ���� ����
            lineStyle: {
                color: "#cc3010",
                width: 10
            }
        },
    ]
};

option && myChart.setOption(option);
