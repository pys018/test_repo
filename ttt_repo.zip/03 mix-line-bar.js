
var emphasisStyle = {
    itemStyle: {
        barBorderWidth: 1,
        shadowBlur: 10,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowColor: 'rgba(0,0,0,0.5)'
    }
};


function formatAxisPointerLabel(value) {
    // console.log(">>>>> value ::: " + JSON.stringify(value));

	var label = value.value;
// 	console.log(">>>>> label ::: " + label);

	if(value.hasOwnProperty('axis'))
	{
		// this is only possible if the proposed solution is in place:
		if(value.axis.model.option.axisLabel.formatter)
		{
			label = value.axis.model.option.axisLabel.formatter.call({}, label);
		}
	}
    // console.log(">>>>> label ::: " + label);
	return label;
}

function formatValue(value, format) {
	switch(format)
	{
	case 0:
		value = "x-" + value;
		break;
	case 1:
		value = "y1-" + value;
		break;

	case 2:
		value = "y2-" + value;
		break;
	}

	return value;
}


option = {
    tooltip: {
        "show": true,
        trigger: 'axis',
        //trigger: 'item',
        axisPointer: {
            type: 'cross',
            crossStyle: {
                color: '#999'
            },
			"label": {
				"formatter": function (params) {
					return formatAxisPointerLabel(params);
				}
			}
        },
        // formatter: function(params) {
        //     return `${params.value}: ${params.data.time}`;
        // }

        //formatter: '{b2} 20210110 1330 <br> {a2} :: {c2} <br> {a3} :: {c3}',

        //formatter: function(params) {
          //return echarts.format.formatTime('yyyy-MM-dd', params.value);
        //}
        // formatter: function(params) {
        //     //console.log("params ::: " + JSON.stringify(params));
        // 	return `${params[0].name} ::: ${params[0].value}`;
        // }
    },
    toolbox: {
        feature: {
            //dataView: {show: true, readOnly: false},
            //magicType: {show: true, type: ['line', 'bar']},
            //restore: {show: true},
            //saveAsImage: {show: true},

            dataZoom: {
                yAxisIndex: 'none'
            },
            restore: {},
        }
    },
    legend: {
        data: ['20190711', '20201112']   // ����Ʈ�� ǥ�� ����
    },
    xAxis: [
        {
            type: 'category',
            //data: ['-45', '-40', '-35', '-30', '-25', '-20', '-15', '-10', '-5', '0', '5', '10', '15', '20', '25', '30', '35', '40'],
            data: [
            	{
            		value: -45,
            		name: '-45',
            		value1: -45,
            		name1: 'AA11'
            	},
            	{
            		value: -40,
            		name: '-40',
            		value1: -40,
            		name1: 'BB11'
            	},

            	{
            		value: -35,
            		name: 'CC',
            		value1: -35,
            		name1: 'CC11'
            	},
            	{
            		value: -30,
            		name: 'DD',
            		value1: -30,
            		name1: 'DD11'
            	},
            	{
            		value: -25,
            		name: 'EE',
            		value1: -25,
            		name1: 'EE11'
            	},
            	{
            		value: -20,
            		name: 'FF',
            		value1: -20,
            		name1: 'FF11'
            	},
            	{
            		value: -15,
            		name: 'GG',
            		value1: -15,
            		name1: 'GG11'
            	},
            	{
            		value: -10,
            		name: 'HH',
            		value1: -10,
            		name1: 'HH11'
            	},
            	{
            		value: -5,
            		name: 'II',
            		value1: -5,
            		name1: 'II11'
            	},
            	{
            		value: 0,
            		name: 'JJ',
            		value1: 0,
            		name1: 'JJ11'
            	},
            	{
            		value: 5,
            		name: 'KK',
            		value1: 5,
            		name1: 'KK11'
            	},
            	{
            		value: 10,
            		name: 'LL',
            		value1: 10,
            		name1: 'LL11'
            	},
            	{
            		value: 15,
            		name: 'MM',
            		value1: 15,
            		name1: 'MM11'
            	},
            	{
            		value: 20,
            		name: 'NN',
            		value1: 20,
            		name1: 'NN11'
            	},
            	{
            		value: 25,
            		name: 'OO',
            		value1: 25,
            		name1: 'OO11'
            	},
            	{
            		value: 30,
            		name: 'PP',
            		value1: 30,
            		name1: 'PP11'
            	},
            	{
            		value: 35,
            		name: 'QQ',
            		value1: 35,
            		name1: 'QQ11'
            	},
            	{
            		value: 40,
            		name: 'RR',
            		value1: 40,
            		name1: 'RR11'
            	}
			],

            axisPointer: {
                type: 'shadow'
            },
            splitLine: {
                show: true
            },
            boundaryGap: false,
            axisLine: {onZero: true},
            //splitLine: {show: false},
            splitArea: {show: false},
        }
    ],
    yAxis: [
        // BAR 1
        {
            type: 'value',
            name: 'Price',
            min: -2,
            max: 0.8,
            interval: 50,
            axisLabel: {
                formatter: '{value}'
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%'],
            inverse: false,
            splitArea: {show: false}
        },
        // BAR 2
        {
            type: 'value',
            name: '',
            min: -2,
            max: 0.8,
            interval: 50,
            axisLabel: {
                formatter: '{value}'
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
        // LINE 1 -- 20190711
        {
            type: 'value',
            name: '',
            min: -2,
            max: 0.8,
            interval: 5,
            axisLabel: {
                //formatter: '{value} ��C',
                lineHeight: 1,
                color: "#cc3010",
            },
            axisLine: {
                show: false,
                lineStyle: {
                    color: "#061736",
                    height: 10
                }
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
        // LINE 2 -- 20201112
        {
            type: 'value',
            name: '',
            min: -2,
            max: 0.8,
            interval: 5,
            axisLabel: {
                //formatter: '{value} ��C',
                lineHeight: 1,
                color: "#cc3010",
            },
            axisLine: {
                show: false,
                lineStyle: {
                    color: "#6E7079",
                    height: 10
                }
            },
            splitLine: {
                show: true
            },
            boundaryGap: [0, '100%']
        },
    ],

    dataZoom: [{
        type: 'inside',
        start: 0,
        end: 100
    }, {
        start: 0,
        end: 100
    }],

    series: [
        {
            name: '��?��',
            type: 'bar',
            stack: 'one',
            emphasis: emphasisStyle,
            data: [0, 0, 0, 0, 0, 0.8, 0, 0, 0, 0.8, 0, 0, 0, 0, 0, 0, 0, 0],  // ���� �ְ�������...
            barWidth: 1,
            color: "#cc3010",
        },
        {
            name: '��?��2',
            type: 'bar',
            stack: 'one',
            emphasis: emphasisStyle,
            data: [0, 0, 0, 0, 0, -2, 0, 0, 0, -2, 0, 0, 0, 0, 0, 0, 0, 0],  // ���� ����������...
            barWidth: 1,
            color: "#cc3010",
        },
        {
            name: '20190711',
            type: 'line',
            yAxisIndex: 2,
            data: [-0.6, -0.2, -0.1, -0.7, -0.4, -0.3, -0.6, -0.1, 0, 0.2, 0.4, 0.7, -0.2, -0.5, 0.3, 0.4, 0.1, -0.3],
            lineStyle: {
                color: "#061736",
                width: 2
            }
        },
        {
            name: '20201112',
            type: 'line',
            yAxisIndex: 1,
            data: [-1.6, -1.2, -1.3, -1.0, -1.2, -1.1, 0.1, 0.3, 0.5, 0.3],    // �ƿ� ���� ���� ���� ����
            lineStyle: {
                color: "#cc3010",
                width: 10
            }
        },
    ]
};

option && myChart.setOption(option);
